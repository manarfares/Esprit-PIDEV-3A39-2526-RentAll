-- ============================================
-- Script pour créer un compte de test
-- Base de données: pidev_amine
-- Table: user
-- ============================================

USE pidev_amine;

-- Vérifier si le compte existe déjà
DELETE FROM user WHERE email = 'test@example.com';

-- Créer le compte de test
-- Email: test@example.com
-- Mot de passe: 123456
-- Hash BCrypt pour "123456": $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
INSERT INTO user (name, email, password, roles, status, created_at, updated_at) 
VALUES (
    'Test Admin',
    'test@example.com',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '["ROLE_ADMIN"]',
    'ACTIVE',
    NOW(),
    NOW()
);

-- Vérifier que le compte a été créé
SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';

-- ============================================
-- RÉSULTAT ATTENDU:
-- ============================================
-- Vous devriez voir une ligne avec:
-- - name: Test Admin
-- - email: test@example.com
-- - roles: ["ROLE_ADMIN"]
-- - status: ACTIVE
-- ============================================

-- ============================================
-- IDENTIFIANTS DE CONNEXION:
-- ============================================
-- Email ou Username: test@example.com  OU  Test Admin
-- Mot de passe: 123456
-- ============================================
