# 🚀 Guide de Lancement - RentAll Java

## ✅ Prérequis
- ✅ Java 21 installé
- ✅ Maven 3.9.15 installé (dans Downloads)
- ✅ MySQL en cours d'exécution (XAMPP/WAMP)
- ✅ Base de données `pidev_amine` accessible

## 📦 Compilation du Projet

```cmd
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" clean compile
```

## 🎯 Lancement de l'Application

### Option 1 : Fichier Batch (Recommandé)
Double-cliquez sur : **`lancer-application.bat`**

### Option 2 : Ligne de commande
```cmd
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java
```

### Option 3 : IntelliJ IDEA
1. Ouvrez le projet dans IntelliJ IDEA
2. Cliquez droit sur `com.rentall.views.App`
3. Sélectionnez "Run 'App.main()'"

## 🧪 Tests CRUD en Console

### Option 1 : Fichier Batch
Double-cliquez sur : **`lancer-tests-console.bat`**

### Option 2 : Ligne de commande
```cmd
REM Modifier temporairement le pom.xml pour pointer vers com.rentall.Main
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java
```

## 📱 Points d'Entrée Disponibles

### 1. **com.rentall.views.App** (Interface Graphique Swing)
   - Interface graphique principale
   - Gestion des réservations et avis
   - Génération de PDF

### 2. **com.rentall.Main** (Tests CRUD Console)
   - Tests automatiques CRUD
   - Affichage en console
   - Validation des opérations

### 3. **com.rentall.Menu** (Menu Interactif Console)
   - Menu interactif en ligne de commande
   - Navigation par numéros

### 4. **tn.piapp.ui.MainApp** (Interface JavaFX)
   - Interface JavaFX moderne
   - Gestion des services et outils

## 🗄️ Configuration Base de Données

Le projet se connecte à :
- **Hôte** : localhost:3306
- **Base** : pidev_amine
- **User** : root
- **Password** : (vide)

Pour modifier la connexion, éditez :
- `src/main/java/com/rentall/config/DatabaseConnection.java`
- `src/main/java/tn/piapp/db/DbConnection.java`

## 📝 Structure du Projet

```
RentAll-Groupe/
├── src/main/java/
│   ├── com/rentall/          # Module Réservations & Avis
│   │   ├── config/           # Configuration DB
│   │   ├── entities/         # Entités (Reservation, Avis)
│   │   ├── services/         # Services métier
│   │   ├── views/            # Interfaces Swing
│   │   └── Main.java         # Tests CRUD
│   │
│   └── tn/piapp/             # Module Services & Outils
│       ├── dao/              # Data Access Objects
│       ├── model/            # Modèles
│       ├── service/          # Services
│       └── ui/               # Interfaces JavaFX
│
├── factures/                 # PDFs générés
├── pom.xml                   # Configuration Maven
└── lancer-application.bat    # Script de lancement

```

## 🔧 Dépannage

### Erreur : "mvn n'est pas reconnu"
Maven n'est pas dans le PATH. Utilisez le chemin complet ou les fichiers .bat fournis.

### Erreur : "Cannot connect to database"
Vérifiez que MySQL est démarré (XAMPP/WAMP) et que la base `pidev_amine` existe.

### Erreur : "Module not found"
Recompilez le projet :
```cmd
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" clean compile
```

## ✨ Fonctionnalités Testées

✅ Connexion à la base de données
✅ CRUD Réservations (Create, Read, Update, Delete)
✅ CRUD Avis (Create, Read, Update, Delete)
✅ Génération de PDF pour les factures
✅ Validation des contraintes de clés étrangères
✅ Interface graphique Swing
✅ Tests automatisés

## 📞 Support

Pour toute question, consultez les logs dans la console ou vérifiez les messages d'erreur MySQL.

---
**Projet RentAll - Version 1.0-SNAPSHOT**
