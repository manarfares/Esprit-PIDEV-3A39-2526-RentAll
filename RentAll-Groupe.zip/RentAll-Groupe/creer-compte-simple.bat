@echo off
chcp 65001 >nul
echo ========================================
echo   Creation du compte de test
echo ========================================
echo.
echo Recherche de MySQL...
echo.

REM Chercher MySQL dans XAMPP
if exist "C:\xampp\mysql\bin\mysql.exe" (
    echo MySQL trouve dans XAMPP
    "C:\xampp\mysql\bin\mysql.exe" -u root pidev_amine < create-test-account.sql
    goto :success
)

REM Chercher MySQL dans WAMP
if exist "C:\wamp64\bin\mysql\mysql8.0.31\bin\mysql.exe" (
    echo MySQL trouve dans WAMP
    "C:\wamp64\bin\mysql\mysql8.0.31\bin\mysql.exe" -u root pidev_amine < create-test-account.sql
    goto :success
)

if exist "C:\wamp64\bin\mysql\mysql8.0.30\bin\mysql.exe" (
    echo MySQL trouve dans WAMP
    "C:\wamp64\bin\mysql\mysql8.0.30\bin\mysql.exe" -u root pidev_amine < create-test-account.sql
    goto :success
)

echo.
echo MySQL non trouve automatiquement.
echo.
echo SOLUTION MANUELLE:
echo 1. Ouvrez phpMyAdmin: http://localhost/phpmyadmin
echo 2. Selectionnez la base 'pidev_amine'
echo 3. Cliquez sur 'SQL'
echo 4. Copiez le contenu du fichier 'create-test-account.sql'
echo 5. Collez et executez
echo.
goto :end

:success
echo.
echo ========================================
echo   Compte cree avec succes!
echo ========================================
echo.
echo Email:        test@example.com
echo Mot de passe: 123456
echo Role:         ADMIN
echo.
echo Vous pouvez maintenant vous connecter!
echo.

:end
pause
