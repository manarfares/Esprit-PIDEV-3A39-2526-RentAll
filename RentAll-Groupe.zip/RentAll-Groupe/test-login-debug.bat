@echo off
echo ========================================
echo   LANCEMENT APPLICATION - MODE DEBUG
echo ========================================
echo.
echo Les logs de connexion s'afficheront dans cette console.
echo.
pause

"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java "-Dexec.mainClass=tn.piapp.ui.MainApp"

pause
