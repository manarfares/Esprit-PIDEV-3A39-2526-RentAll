@echo off
echo ========================================
echo   Lancement de l'application RentAll
echo   Interface Principale du Groupe
echo ========================================
echo.
echo Compilation et lancement en cours...
echo.
echo L'interface JavaFX du groupe va s'ouvrir.
echo Utilisez les boutons "Reservations" et "Avis"
echo dans le menu pour acceder aux modules.
echo.

"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java

pause
