# 🔐 Création du Compte de Test

## ⚡ Solution Rapide - Exécuter le SQL

### Option 1 : Via phpMyAdmin (Recommandé)

1. **Ouvrez phpMyAdmin** : http://localhost/phpmyadmin
2. **Sélectionnez la base** : `pidev_amine`
3. **Cliquez sur l'onglet "SQL"**
4. **Copiez et collez ce code** :

```sql
-- Supprimer l'ancien compte s'il existe
DELETE FROM user WHERE email = 'test@example.com';

-- Créer le nouveau compte
INSERT INTO user (name, email, password, roles, status, created_at, updated_at) 
VALUES (
    'Test Admin',
    'test@example.com',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '["ROLE_ADMIN"]',
    'ACTIVE',
    NOW(),
    NOW()
);

-- Vérifier que le compte a été créé
SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';
```

5. **Cliquez sur "Exécuter"**

### Option 2 : Via MySQL Command Line

```bash
mysql -u root -p
```

Puis exécutez :
```sql
USE pidev_amine;

DELETE FROM user WHERE email = 'test@example.com';

INSERT INTO user (name, email, password, roles, status, created_at, updated_at) 
VALUES (
    'Test Admin',
    'test@example.com',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '["ROLE_ADMIN"]',
    'ACTIVE',
    NOW(),
    NOW()
);

SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';
```

### Option 3 : Fichier SQL fourni

Double-cliquez sur le fichier **`create-test-account.sql`** et importez-le dans phpMyAdmin.

## ✅ Identifiants de Connexion

Une fois le compte créé, utilisez ces identifiants dans l'application :

```
📧 Email/Username: test@example.com
🔑 Mot de passe:   123456
👤 Rôle:           ADMIN
```

## 🔍 Vérification

Pour vérifier que le compte existe :

```sql
USE pidev_amine;
SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';
```

Vous devriez voir :
- **name**: Test Admin
- **email**: test@example.com
- **roles**: ["ROLE_ADMIN"]
- **status**: ACTIVE

## 📋 Structure de la Table `user`

Le code utilise la table **`user`** (pas `utilisateur`) avec ces colonnes :
- `id` - INT (auto-increment)
- `name` - VARCHAR (nom d'utilisateur)
- `email` - VARCHAR (email)
- `password` - VARCHAR (hash BCrypt)
- `roles` - JSON (ex: ["ROLE_ADMIN"])
- `status` - VARCHAR (ACTIVE, INACTIVE, BANNED)
- `session_token` - VARCHAR (nullable)
- `phone` - VARCHAR (nullable)
- `profile_image` - VARCHAR (nullable)
- `host_request_date` - DATETIME (nullable)
- `created_at` - DATETIME
- `updated_at` - DATETIME

## 🔐 À propos du Hash BCrypt

Le hash `$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy` correspond au mot de passe **`123456`**.

BCrypt est un algorithme de hashing sécurisé. Vous ne pouvez pas "décrypter" un hash BCrypt, vous devez le régénérer.

## ⚠️ Dépannage

### Le compte ne se crée pas
- Vérifiez que la table `user` existe dans `pidev_amine`
- Vérifiez que MySQL est démarré
- Vérifiez les contraintes de la table (UNIQUE sur email)

### Le login échoue toujours
1. Vérifiez que le compte existe :
   ```sql
   SELECT * FROM user WHERE email = 'test@example.com';
   ```

2. Vérifiez que le status est 'ACTIVE'

3. Vérifiez les logs dans la console de l'application

### Erreur "Identifiant ou mot de passe incorrect"
- Le hash du mot de passe doit être exactement : `$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy`
- Le status doit être 'ACTIVE'
- Les roles doivent être au format JSON : `["ROLE_ADMIN"]`

## 🎯 Après la Connexion

Une fois connecté, vous verrez :
- L'interface principale du groupe (JavaFX)
- La navbar avec les boutons **📅 Réservations** et **⭐ Avis**
- Cliquez sur ces boutons pour accéder à vos modules Swing

---
**Bon test !** 🚀
