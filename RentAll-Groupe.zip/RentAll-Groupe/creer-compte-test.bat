@echo off
echo ========================================
echo   Creation du compte de test
echo ========================================
echo.
echo Email: test@example.com
echo Mot de passe: 123456
echo.
echo Compilation et execution...
echo.

"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" compile exec:java -Dexec.mainClass="com.rentall.tools.CreateTestUser" -Dexec.cleanupDaemonThreads=false

echo.
echo ========================================
pause
