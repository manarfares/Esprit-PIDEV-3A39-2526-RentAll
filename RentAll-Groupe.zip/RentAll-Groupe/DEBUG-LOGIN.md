# 🔍 DEBUG LOGIN - INSTRUCTIONS

## ✅ Modifications effectuées

J'ai ajouté des logs détaillés dans la méthode `login()` de `ServiceUser.java` qui afficheront :

### 📊 Informations affichées dans la console :
1. ✅ Email saisi
2. ✅ Mot de passe saisi (longueur)
3. ✅ Utilisateur trouvé ou non
4. ✅ Toutes les colonnes de la base :
   - `id`
   - `nom`
   - `prenom`
   - `roles`
   - `account_status`
   - `is_verified`
5. ✅ Hash complet récupéré depuis la base
6. ✅ Résultat de `BCrypt.checkpw()` (SUCCÈS ou ÉCHEC)
7. ✅ Détails de la session si connexion réussie

## 🚀 Comment tester

### Option 1 : Avec le fichier batch
```cmd
test-login-debug.bat
```

### Option 2 : Avec Maven directement
```cmd
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java "-Dexec.mainClass=tn.piapp.ui.MainApp"
```

### Option 3 : Dans IntelliJ
1. Cliquez sur le bouton ▶️ Run
2. Regardez la console en bas de l'écran
3. Essayez de vous connecter avec :
   - Email : `test@example.com`
   - Mot de passe : `123456`

## 📝 Ce que vous verrez dans la console

```
╔════════════════════════════════════════════════════════════════╗
║                    TENTATIVE DE CONNEXION                      ║
╚════════════════════════════════════════════════════════════════╝
📧 Email saisi          : test@example.com
🔑 Mot de passe saisi   : 123456
📝 Longueur mot de passe: 6 caractères

✅ UTILISATEUR TROUVÉ DANS LA BASE
   ID                : 1
   Nom               : Test
   Prénom            : Admin
   Roles             : ["ROLE_ADMIN"]
   Account Status    : active
   Is Verified       : 1
   Hash (30 premiers): $2a$10$N9qo8uLO...
   Hash complet      : $2a$10$N9qo8uLO... (complet)

🔐 VÉRIFICATION BCRYPT...
   Password fourni   : '123456'
   Hash en base      : '$2a$10$...'
   Résultat BCrypt   : ✅ SUCCÈS ou ❌ ÉCHEC
```

## 🎯 Objectif

Identifier **exactement** quelle condition bloque la connexion :
- ❓ L'utilisateur n'est pas trouvé ?
- ❓ Le hash BCrypt ne correspond pas ?
- ❓ Le `account_status` n'est pas correct ?
- ❓ Le `is_verified` pose problème ?

## 📋 Informations du compte test

D'après votre base de données :
- **Email** : test@example.com
- **Password** : commence par `$2a$10$N9qo8uLO...`
- **Roles** : `["ROLE_ADMIN"]`
- **is_verified** : 1
- **account_status** : active

## ⚠️ Important

- ✅ Aucune modification de la base de données
- ✅ Seulement des logs ajoutés dans le code Java
- ✅ Le projet compile sans erreur
- ✅ Prêt à tester

## 📸 Après le test

Envoyez-moi une capture d'écran ou copiez le texte de la console pour que je puisse voir exactement où ça bloque.
