package com.rentall.tools;

import org.mindrot.jbcrypt.BCrypt;
import tn.piapp.db.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Outil pour créer un utilisateur de test avec les identifiants:
 * Email: test@example.com
 * Password: 123456
 */
public class CreateTestUser {

    public static void main(String[] args) {
        try {
            Connection conn = DbConnection.getInstance().getConnection();
            
            System.out.println("╔══════════════════════════════════════════════════════╗");
            System.out.println("║     Création du compte de test                       ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            System.out.println();
            
            String email = "test@example.com";
            String password = "123456";
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
            
            System.out.println("🔑 Génération du hash BCrypt...");
            System.out.println("   Mot de passe : " + password);
            System.out.println("   Hash : " + hashedPassword.substring(0, 30) + "...");
            System.out.println();
            
            // Vérifier si le compte existe
            String sqlCheck = "SELECT id, nom, prenom, email, password FROM user WHERE email = ?";
            PreparedStatement psCheck = conn.prepareStatement(sqlCheck);
            psCheck.setString(1, email);
            ResultSet rs = psCheck.executeQuery();
            
            if (rs.next()) {
                int id = rs.getInt("id");
                System.out.println("⚠️  Compte existant trouvé (ID: " + id + ")");
                System.out.println("   Mise à jour du mot de passe...");
                
                // Mettre à jour le mot de passe
                String sqlUpdate = "UPDATE user SET password = ?, account_status = 'active', is_verified = 1, " +
                                   "nom = 'Admin', prenom = 'Test', roles = '[\"ROLE_ADMIN\"]' WHERE email = ?";
                PreparedStatement psUpdate = conn.prepareStatement(sqlUpdate);
                psUpdate.setString(1, hashedPassword);
                psUpdate.setString(2, email);
                psUpdate.executeUpdate();
                
                System.out.println("✅ Compte mis à jour avec succès !");
            } else {
                System.out.println("📝 Création d'un nouveau compte...");
                
                // Créer le nouveau compte avec les bonnes colonnes
                String sqlInsert = "INSERT INTO user (nom, prenom, email, password, roles, account_status, is_verified, created_at) " +
                                   "VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
                PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
                psInsert.setString(1, "Admin");
                psInsert.setString(2, "Test");
                psInsert.setString(3, email);
                psInsert.setString(4, hashedPassword);
                psInsert.setString(5, "[\"ROLE_ADMIN\"]");
                psInsert.setString(6, "active");
                psInsert.setInt(7, 1);
                psInsert.executeUpdate();
                
                System.out.println("✅ Compte créé avec succès !");
            }
            
            System.out.println();
            System.out.println("╔══════════════════════════════════════════════════════╗");
            System.out.println("║     IDENTIFIANTS DE CONNEXION                        ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            System.out.println();
            System.out.println("  📧 Email:          test@example.com");
            System.out.println("  🔑 Mot de passe:   123456");
            System.out.println("  👤 Rôle:           ADMIN");
            System.out.println();
            
            // Vérifier que le compte existe et tester BCrypt
            String sqlSelect = "SELECT id, nom, prenom, email, roles, account_status, password FROM user WHERE email = ?";
            PreparedStatement psSelect = conn.prepareStatement(sqlSelect);
            psSelect.setString(1, email);
            ResultSet rsVerif = psSelect.executeQuery();
            
            if (rsVerif.next()) {
                System.out.println("✅ Vérification du compte:");
                System.out.println("   ID:             " + rsVerif.getInt("id"));
                System.out.println("   Nom:            " + rsVerif.getString("nom"));
                System.out.println("   Prénom:         " + rsVerif.getString("prenom"));
                System.out.println("   Email:          " + rsVerif.getString("email"));
                System.out.println("   Roles:          " + rsVerif.getString("roles"));
                System.out.println("   Account Status: " + rsVerif.getString("account_status"));
                
                String storedHash = rsVerif.getString("password");
                System.out.println("   Hash stocké:    " + storedHash.substring(0, 30) + "...");
                
                // Test BCrypt
                if (BCrypt.checkpw(password, storedHash)) {
                    System.out.println("   ✅ Test BCrypt: SUCCÈS");
                } else {
                    System.out.println("   ❌ Test BCrypt: ÉCHEC");
                }
            }
            
            System.out.println();
            System.out.println("╔══════════════════════════════════════════════════════╗");
            System.out.println("║  Vous pouvez maintenant vous connecter !             ║");
            System.out.println("╚══════════════════════════════════════════════════════╝");
            
        } catch (SQLException e) {
            System.out.println("❌ Erreur SQL : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
