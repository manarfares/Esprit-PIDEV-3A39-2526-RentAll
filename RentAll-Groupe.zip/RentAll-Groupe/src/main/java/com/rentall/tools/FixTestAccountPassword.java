package com.rentall.tools;

import org.mindrot.jbcrypt.BCrypt;
import tn.piapp.db.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FixTestAccountPassword {

    private static final String EMAIL = "test@example.com";
    private static final String PASSWORD = "123456";
    private static final String ROLES = "[\"ROLE_ADMIN\"]";

    public static void main(String[] args) throws Exception {
        Connection connection = DbConnection.getInstance().getConnection();
        String hash = BCrypt.hashpw(PASSWORD, BCrypt.gensalt());

        String updateSql =
                "UPDATE user " +
                "SET password = ?, " +
                "roles = ?, " +
                "is_verified = 1, " +
                "account_status = 'active' " +
                "WHERE email = ?";

        try (PreparedStatement update = connection.prepareStatement(updateSql)) {
            update.setString(1, hash);
            update.setString(2, ROLES);
            update.setString(3, EMAIL);

            int updatedRows = update.executeUpdate();
            if (updatedRows != 1) {
                throw new IllegalStateException("Compte introuvable ou mise a jour ambigue: " + updatedRows + " ligne(s).");
            }
        }

        String selectSql =
                "SELECT email, password, roles, is_verified, account_status " +
                "FROM user " +
                "WHERE email = ?";

        try (PreparedStatement select = connection.prepareStatement(selectSql)) {
            select.setString(1, EMAIL);

            try (ResultSet result = select.executeQuery()) {
                if (!result.next()) {
                    throw new IllegalStateException("Compte introuvable apres mise a jour.");
                }

                String storedHash = result.getString("password");
                boolean passwordMatches = BCrypt.checkpw(PASSWORD, storedHash);

                System.out.println("email = " + result.getString("email"));
                System.out.println("roles = " + result.getString("roles"));
                System.out.println("is_verified = " + result.getInt("is_verified"));
                System.out.println("account_status = " + result.getString("account_status"));
                System.out.println("hash = " + storedHash);
                System.out.println("BCrypt.checkpw(\"123456\", hashDeLaBase) = " + passwordMatches);

                if (!passwordMatches) {
                    throw new IllegalStateException("Le hash stocke ne correspond pas au mot de passe 123456.");
                }
            }
        }
    }
}
