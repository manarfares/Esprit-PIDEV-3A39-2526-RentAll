package com.rentall.tools;

import org.mindrot.jbcrypt.BCrypt;
import tn.piapp.db.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class PrepareRoleUserAccount {

    private static final String EMAIL = "usertest@example.com";
    private static final String PASSWORD = "123456";
    private static final String ROLES = "[\"ROLE_USER\"]";

    public static void main(String[] args) throws Exception {
        Connection connection = DbConnection.getInstance().getConnection();
        String hash = BCrypt.hashpw(PASSWORD, BCrypt.gensalt());

        boolean exists;
        try (PreparedStatement check = connection.prepareStatement("SELECT id FROM user WHERE email = ?")) {
            check.setString(1, EMAIL);
            try (ResultSet result = check.executeQuery()) {
                exists = result.next();
            }
        }

        if (exists) {
            String updateSql =
                    "UPDATE user " +
                    "SET password = ?, " +
                    "roles = ?, " +
                    "is_verified = 1, " +
                    "account_status = 'active' " +
                    "WHERE email = ?";

            try (PreparedStatement update = connection.prepareStatement(updateSql)) {
                update.setString(1, hash);
                update.setString(2, ROLES);
                update.setString(3, EMAIL);
                update.executeUpdate();
            }
        } else {
            String insertSql =
                    "INSERT INTO user (nom, prenom, email, password, roles, account_status, is_verified) " +
                    "VALUES (?, ?, ?, ?, ?, 'active', 1)";

            try (PreparedStatement insert = connection.prepareStatement(insertSql)) {
                insert.setString(1, "Test");
                insert.setString(2, "User");
                insert.setString(3, EMAIL);
                insert.setString(4, hash);
                insert.setString(5, ROLES);
                insert.executeUpdate();
            }
        }

        String selectSql =
                "SELECT email, password, roles, is_verified, account_status " +
                "FROM user " +
                "WHERE email = ?";

        try (PreparedStatement select = connection.prepareStatement(selectSql)) {
            select.setString(1, EMAIL);

            try (ResultSet result = select.executeQuery()) {
                if (!result.next()) {
                    throw new IllegalStateException("Compte ROLE_USER introuvable apres preparation.");
                }

                String storedHash = result.getString("password");
                boolean passwordMatches = BCrypt.checkpw(PASSWORD, storedHash);

                System.out.println("email = " + result.getString("email"));
                System.out.println("roles = " + result.getString("roles"));
                System.out.println("is_verified = " + result.getInt("is_verified"));
                System.out.println("account_status = " + result.getString("account_status"));
                System.out.println("BCrypt.checkpw(\"123456\", hashDeLaBase) = " + passwordMatches);

                if (!passwordMatches) {
                    throw new IllegalStateException("Le hash stocke ne correspond pas au mot de passe 123456.");
                }
            }
        }
    }
}
