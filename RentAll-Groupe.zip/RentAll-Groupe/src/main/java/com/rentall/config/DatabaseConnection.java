package com.rentall.config;

import java.sql.Connection;
import java.sql.SQLException;

import tn.piapp.db.DbConnection;

public class DatabaseConnection {

    public static Connection getConnection() {
        try {
            return DbConnection.getInstance().getConnection();
        } catch (SQLException e) {
            System.out.println("Erreur de connexion : " + e.getMessage());
            return null;
        }
    }
}
