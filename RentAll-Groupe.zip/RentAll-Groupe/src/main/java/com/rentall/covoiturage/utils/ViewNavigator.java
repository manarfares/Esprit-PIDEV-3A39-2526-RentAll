package com.rentall.covoiturage.utils;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import tn.piapp.ui.IntegratedCovoiturageView;

import java.io.IOException;
import java.util.function.Consumer;

public final class ViewNavigator {
    private ViewNavigator() {
    }

    public static void navigate(Node sourceNode, String fxmlPath) throws IOException {
        navigate(sourceNode, fxmlPath, controller -> {
        });
    }

    public static void navigate(Node sourceNode, String fxmlPath, Consumer<Object> controllerConfigurer) throws IOException {
        IntegratedCovoiturageView integratedView = IntegratedCovoiturageView.findOwner(sourceNode);
        if (integratedView != null) {
            integratedView.show(fxmlPath, controllerConfigurer);
            return;
        }

        FXMLLoader loader = new FXMLLoader(IntegratedCovoiturageView.class.getResource(fxmlPath));
        Parent root = loader.load();
        controllerConfigurer.accept(loader.getController());

        Stage stage = (Stage) sourceNode.getScene().getWindow();
        Scene scene = new Scene(root, 1100, 720);
        scene.getStylesheets().add(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/styles/covoiturage.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }
}
