package com.rentall.covoiturage.utils;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

public class InputValidator {

    private static final Pattern CITY_LETTERS_AND_SPACES_ONLY = Pattern.compile("^[a-zA-Z\\u00C0-\\u00FF\\s]+$");
    private static final Pattern TIME_PATTERN = Pattern.compile("^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$");
    private static final int MAX_COMMENT_LENGTH = 255;
    private static final int COVOITURAGE_MIN_PLACES = 1;
    private static final int COVOITURAGE_MAX_PLACES = 8;

    public static ValidationResult validerVille(String ville, String nomChamp) {
        if (ville == null || ville.trim().isEmpty()) {
            return ValidationResult.error(nomChamp + " est obligatoire.");
        }

        String trimmed = ville.trim();

        if (trimmed.length() < 2) {
            return ValidationResult.error(nomChamp + " doit contenir au moins 2 caracteres.");
        }

        if (trimmed.length() > 120) {
            return ValidationResult.error(nomChamp + " ne peut pas depasser 120 caracteres.");
        }

        if (!CITY_LETTERS_AND_SPACES_ONLY.matcher(trimmed).matches()) {
            return ValidationResult.error(nomChamp + " ne doit contenir que des lettres et des espaces.");
        }

        return ValidationResult.success(trimmed);
    }

    public static ValidationResult validerHeure(String heure, String nomChamp) {
        if (heure == null || heure.trim().isEmpty()) {
            return ValidationResult.error(nomChamp + " est obligatoire.");
        }

        String trimmed = heure.trim();

        if (!TIME_PATTERN.matcher(trimmed).matches()) {
            return ValidationResult.error("Format d'heure invalide. Utilisez HH:mm (ex: 14:30)");
        }

        try {
            LocalTime.parse(trimmed, DateTimeFormatter.ofPattern("HH:mm"));
            return ValidationResult.success(trimmed);
        } catch (DateTimeParseException e) {
            return ValidationResult.error("Heure invalide. Verifiez le format HH:mm");
        }
    }

    public static ValidationResult validerDateDepart(LocalDate date, boolean allowPast) {
        if (date == null) {
            return ValidationResult.error("Veuillez choisir une date de depart.");
        }

        if (!allowPast && date.isBefore(LocalDate.now())) {
            return ValidationResult.error("La date de depart ne peut pas etre dans le passe.");
        }

        return ValidationResult.success(date);
    }

    public static ValidationResult validerPrix(String prix, String nomChamp) {
        if (prix == null || prix.trim().isEmpty()) {
            return ValidationResult.error(nomChamp + " est obligatoire.");
        }

        String trimmed = prix.trim().replace(',', '.');

        try {
            double value = Double.parseDouble(trimmed);
            if (value <= 0) {
                return ValidationResult.error(nomChamp + " doit etre superieur a 0.");
            }
            return ValidationResult.success(value);
        } catch (NumberFormatException e) {
            return ValidationResult.error(nomChamp + " doit etre un nombre valide.");
        }
    }

    public static ValidationResult validerNombrePlaces(Integer places, int min, int max, String nomChamp) {
        if (places == null) {
            return ValidationResult.error(nomChamp + " est obligatoire.");
        }

        if (places < min) {
            return ValidationResult.error(nomChamp + " doit etre au moins " + min + ".");
        }

        if (places > max) {
            return ValidationResult.error(nomChamp + " ne peut pas depasser " + max + ".");
        }

        return ValidationResult.success(places);
    }

    public static ValidationResult validerPlacesCovoiturage(Integer places) {
        return validerNombrePlaces(places, COVOITURAGE_MIN_PLACES, COVOITURAGE_MAX_PLACES, "Le nombre de places");
    }

    public static ValidationResult validerCommentaire(String commentaire) {
        if (commentaire == null) {
            return ValidationResult.success("");
        }

        String trimmed = commentaire.trim();
        if (trimmed.length() > MAX_COMMENT_LENGTH) {
            return ValidationResult.error("Le commentaire ne peut pas depasser " + MAX_COMMENT_LENGTH + " caracteres.");
        }

        return ValidationResult.success(trimmed);
    }

    public static ValidationResult validerConducteurId(String conducteurId) {
        if (conducteurId == null || conducteurId.trim().isEmpty()) {
            return ValidationResult.error("Le conducteurId est obligatoire.");
        }

        String trimmed = conducteurId.trim();
        try {
            int value = Integer.parseInt(trimmed);
            if (value <= 0) {
                return ValidationResult.error("Le conducteurId doit etre un entier strictement positif.");
            }
            return ValidationResult.success(value);
        } catch (NumberFormatException e) {
            return ValidationResult.error("Le conducteurId doit etre un entier valide.");
        }
    }

    public static ValidationResult validerCovoiturageComplet(String conducteurId,
                                                             String villeDepart,
                                                             String villeArrivee,
                                                             LocalDate dateDepart,
                                                             String heureDepart,
                                                             String prixParPlace,
                                                             Integer nbPlaces,
                                                             String commentaire) {
        ValidationResult conducteurResult = validerConducteurId(conducteurId);
        if (!conducteurResult.isValid()) {
            return conducteurResult;
        }

        ValidationResult departResult = validerVille(villeDepart, "La ville de depart");
        if (!departResult.isValid()) {
            return departResult;
        }

        ValidationResult arriveeResult = validerVille(villeArrivee, "La ville d'arrivee");
        if (!arriveeResult.isValid()) {
            return arriveeResult;
        }

        String departClean = (String) departResult.getValue();
        String arriveeClean = (String) arriveeResult.getValue();
        if (departClean.equalsIgnoreCase(arriveeClean)) {
            return ValidationResult.error("La ville de depart et la ville d'arrivee doivent etre differentes.");
        }

        ValidationResult dateResult = validerDateDepart(dateDepart, false);
        if (!dateResult.isValid()) {
            return dateResult;
        }

        ValidationResult heureResult = validerHeure(heureDepart, "L'heure de depart");
        if (!heureResult.isValid()) {
            return heureResult;
        }

        ValidationResult prixResult = validerPrix(prixParPlace, "Le prix par place");
        if (!prixResult.isValid()) {
            return prixResult;
        }

        ValidationResult placesResult = validerPlacesCovoiturage(nbPlaces);
        if (!placesResult.isValid()) {
            return placesResult;
        }

        ValidationResult commentaireResult = validerCommentaire(commentaire);
        if (!commentaireResult.isValid()) {
            return commentaireResult;
        }

        try {
            LocalTime time = LocalTime.parse(((String) heureResult.getValue()).trim(), DateTimeFormatter.ofPattern("HH:mm"));
            CovoiturageValues values = new CovoiturageValues(
                    (int) conducteurResult.getValue(),
                    departClean,
                    arriveeClean,
                    (LocalDate) dateResult.getValue(),
                    time,
                    (double) prixResult.getValue(),
                    (int) placesResult.getValue(),
                    (String) commentaireResult.getValue()
            );
            return ValidationResult.success(values);
        } catch (DateTimeParseException e) {
            return ValidationResult.error("Format d'heure invalide. Utilisez HH:mm (ex: 08:30).");
        }
    }

    public static class CovoiturageValues {
        private final int conducteurId;
        private final String villeDepart;
        private final String villeArrivee;
        private final LocalDate dateDepart;
        private final LocalTime heureDepart;
        private final double prixParPlace;
        private final int nbPlaces;
        private final String commentaire;

        public CovoiturageValues(int conducteurId,
                                 String villeDepart,
                                 String villeArrivee,
                                 LocalDate dateDepart,
                                 LocalTime heureDepart,
                                 double prixParPlace,
                                 int nbPlaces,
                                 String commentaire) {
            this.conducteurId = conducteurId;
            this.villeDepart = villeDepart;
            this.villeArrivee = villeArrivee;
            this.dateDepart = dateDepart;
            this.heureDepart = heureDepart;
            this.prixParPlace = prixParPlace;
            this.nbPlaces = nbPlaces;
            this.commentaire = commentaire;
        }

        public int getConducteurId() {
            return conducteurId;
        }

        public String getVilleDepart() {
            return villeDepart;
        }

        public String getVilleArrivee() {
            return villeArrivee;
        }

        public LocalDate getDateDepart() {
            return dateDepart;
        }

        public LocalTime getHeureDepart() {
            return heureDepart;
        }

        public double getPrixParPlace() {
            return prixParPlace;
        }

        public int getNbPlaces() {
            return nbPlaces;
        }

        public String getCommentaire() {
            return commentaire;
        }
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String errorMessage;
        private final Object value;

        private ValidationResult(boolean valid, String errorMessage, Object value) {
            this.valid = valid;
            this.errorMessage = errorMessage;
            this.value = value;
        }

        public static ValidationResult success(Object value) {
            return new ValidationResult(true, null, value);
        }

        public static ValidationResult error(String message) {
            return new ValidationResult(false, message, null);
        }

        public boolean isValid() {
            return valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }

        public Object getValue() {
            return value;
        }
    }
}

