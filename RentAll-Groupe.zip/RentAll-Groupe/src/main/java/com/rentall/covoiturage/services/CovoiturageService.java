package com.rentall.covoiturage.services;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.rentall.covoiturage.models.Covoiturage;
import com.rentall.config.DatabaseConnection;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class CovoiturageService {
    public static final String SUCCESS_MESSAGE = "Connexion reussie a la base de donnees RentAll.";

    private static final String CREATE_TABLE_SQL = """
            CREATE TABLE IF NOT EXISTS covoiturages (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                ville_depart VARCHAR(120) NOT NULL,
                ville_arrivee VARCHAR(120) NOT NULL,
                date_depart DATE NOT NULL,
                heure_depart TIME NOT NULL,
                prix_par_place DOUBLE NOT NULL,
                nb_places INT NOT NULL,
                commentaire VARCHAR(255),
                conducteur_id INT NOT NULL
            )
            """;

    private static final DateTimeFormatter PDF_DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter PDF_TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("0.00");

    private Connection connection;

    public void initialiserBase() throws SQLException {
        try (Statement statement = getConnection().createStatement()) {
            statement.execute(CREATE_TABLE_SQL);
        }
    }

    private Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            connection = DatabaseConnection.getConnection();
        }
        if (connection == null) {
            throw new SQLException("Connexion RentAll indisponible. Verifie MySQL et la base pidev_amine.");
        }
        return connection;
    }

    public void ajouterCovoiturage(Covoiturage covoiturage) throws SQLException {
        String sql = """
                INSERT INTO covoiturages (
                    ville_depart, ville_arrivee, date_depart, heure_depart,
                    prix_par_place, nb_places, commentaire, conducteur_id
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;

        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {

            pstmt.setString(1, covoiturage.getVilleDepart());
            pstmt.setString(2, covoiturage.getVilleArrivee());
            pstmt.setDate(3, Date.valueOf(covoiturage.getDateDepart()));
            pstmt.setTime(4, Time.valueOf(covoiturage.getHeureDepart()));
            pstmt.setDouble(5, covoiturage.getPrixParPlace());
            pstmt.setInt(6, covoiturage.getNbPlaces());
            pstmt.setString(7, covoiturage.getCommentaire());
            pstmt.setInt(8, covoiturage.getConducteurId());
            pstmt.executeUpdate();
        }
    }

    public List<Covoiturage> getAllCovoiturages() throws SQLException {
        List<Covoiturage> covoiturages = new ArrayList<>();
        String sql = """
                SELECT id,
                       ville_depart,
                       ville_arrivee,
                       date_depart,
                       heure_depart,
                       prix_par_place,
                       nb_places,
                       commentaire,
                       conducteur_id
                FROM covoiturages
                ORDER BY date_depart ASC, heure_depart ASC
                """;

        try (Statement stmt = getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                covoiturages.add(new Covoiturage(
                        rs.getLong("id"),
                        rs.getString("ville_depart"),
                        rs.getString("ville_arrivee"),
                        rs.getDate("date_depart").toLocalDate(),
                        rs.getTime("heure_depart").toLocalTime(),
                        rs.getDouble("prix_par_place"),
                        rs.getInt("nb_places"),
                        rs.getString("commentaire"),
                        rs.getInt("conducteur_id")
                ));
            }
        }

        return covoiturages;
    }

    public CovoiturageStatistiques calculerStatistiques() throws SQLException {
        return calculerStatistiques(getAllCovoiturages());
    }

    public CovoiturageStatistiques calculerStatistiques(List<Covoiturage> covoiturages) {
        int totalCovoiturages = covoiturages.size();
        int totalPlaces = covoiturages.stream()
                .mapToInt(Covoiturage::getNbPlaces)
                .sum();
        double prixMoyen = covoiturages.stream()
                .mapToDouble(Covoiturage::getPrixParPlace)
                .average()
                .orElse(0.0);
        double prixMinimum = covoiturages.stream()
                .mapToDouble(Covoiturage::getPrixParPlace)
                .min()
                .orElse(0.0);
        double prixMaximum = covoiturages.stream()
                .mapToDouble(Covoiturage::getPrixParPlace)
                .max()
                .orElse(0.0);
        long totalConducteurs = covoiturages.stream()
                .map(Covoiturage::getConducteurId)
                .distinct()
                .count();

        LocalDateTime prochainDepart = covoiturages.stream()
                .map(covoiturage -> LocalDateTime.of(covoiturage.getDateDepart(), covoiturage.getHeureDepart()))
                .min(Comparator.naturalOrder())
                .orElse(null);

        return new CovoiturageStatistiques(
                totalCovoiturages,
                totalPlaces,
                prixMoyen,
                prixMinimum,
                prixMaximum,
                totalConducteurs,
                prochainDepart
        );
    }

    public void modifierCovoiturage(Covoiturage covoiturage) throws SQLException {
        String sql = """
                UPDATE covoiturages
                SET ville_depart = ?,
                    ville_arrivee = ?,
                    date_depart = ?,
                    heure_depart = ?,
                    prix_par_place = ?,
                    nb_places = ?,
                    commentaire = ?,
                    conducteur_id = ?
                WHERE id = ?
                """;

        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {

            pstmt.setString(1, covoiturage.getVilleDepart());
            pstmt.setString(2, covoiturage.getVilleArrivee());
            pstmt.setDate(3, Date.valueOf(covoiturage.getDateDepart()));
            pstmt.setTime(4, Time.valueOf(covoiturage.getHeureDepart()));
            pstmt.setDouble(5, covoiturage.getPrixParPlace());
            pstmt.setInt(6, covoiturage.getNbPlaces());
            pstmt.setString(7, covoiturage.getCommentaire());
            pstmt.setInt(8, covoiturage.getConducteurId());
            pstmt.setLong(9, covoiturage.getId());
            pstmt.executeUpdate();
        }
    }

    public void supprimerCovoiturage(long id) throws SQLException {
        String sql = "DELETE FROM covoiturages WHERE id = ?";

        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {

            pstmt.setLong(1, id);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SQLException("Aucun covoiturage trouve avec l'ID: " + id);
            }
        }
    }

    public void supprimerCovoiturage(Covoiturage covoiturage) throws SQLException {
        supprimerCovoiturage(covoiturage.getId());
    }

    public void reserverCovoiturage(long id) throws SQLException {
        String sql = """
                UPDATE covoiturages
                SET nb_places = nb_places - 1
                WHERE id = ? AND nb_places > 0
                """;

        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {

            pstmt.setLong(1, id);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("Reservation impossible : aucune place disponible pour cette annonce.");
            }
        }
    }

    public List<Covoiturage> rechercherParVille(String terme) throws SQLException {
        String keyword = terme == null ? "" : terme.trim();
        if (keyword.isEmpty()) {
            return getAllCovoiturages();
        }

        List<Covoiturage> covoiturages = new ArrayList<>();
        String sql = """
                SELECT id,
                       ville_depart,
                       ville_arrivee,
                       date_depart,
                       heure_depart,
                       prix_par_place,
                       nb_places,
                       commentaire,
                       conducteur_id
                FROM covoiturages
                WHERE LOWER(ville_depart) LIKE LOWER(?)
                   OR LOWER(ville_arrivee) LIKE LOWER(?)
                ORDER BY date_depart ASC, heure_depart ASC
                """;

        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {

            String like = "%" + keyword + "%";
            pstmt.setString(1, like);
            pstmt.setString(2, like);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    covoiturages.add(new Covoiturage(
                            rs.getLong("id"),
                            rs.getString("ville_depart"),
                            rs.getString("ville_arrivee"),
                            rs.getDate("date_depart").toLocalDate(),
                            rs.getTime("heure_depart").toLocalTime(),
                            rs.getDouble("prix_par_place"),
                            rs.getInt("nb_places"),
                            rs.getString("commentaire"),
                            rs.getInt("conducteur_id")
                    ));
                }
            }
        }

        return covoiturages;
    }

    public void exporterEnPdf(String filePath) throws SQLException, IOException {
        List<Covoiturage> covoiturages = getAllCovoiturages();
        CovoiturageStatistiques statistiques = calculerStatistiques(covoiturages);

        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            document.add(new Paragraph("Rapport des covoiturages", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18)));
            document.add(new Paragraph(" "));
            document.add(new Paragraph("Total covoiturages : " + statistiques.getTotalCovoiturages()));
            document.add(new Paragraph("Total places : " + statistiques.getTotalPlaces()));
            document.add(new Paragraph("Prix moyen : " + PRICE_FORMAT.format(statistiques.getPrixMoyen()) + " DT"));
            document.add(new Paragraph("Prix min : " + PRICE_FORMAT.format(statistiques.getPrixMinimum()) + " DT"));
            document.add(new Paragraph("Prix max : " + PRICE_FORMAT.format(statistiques.getPrixMaximum()) + " DT"));
            document.add(new Paragraph("Conducteurs distincts : " + statistiques.getTotalConducteurs()));
            document.add(new Paragraph("Prochain depart : " + formatDateTime(statistiques.getProchainDepart())));
            document.add(new Paragraph(" "));

            PdfPTable table = new PdfPTable(9);
            table.setWidthPercentage(100);
            table.addCell(new Phrase("ID"));
            table.addCell(new Phrase("Depart"));
            table.addCell(new Phrase("Arrivee"));
            table.addCell(new Phrase("Date"));
            table.addCell(new Phrase("Heure"));
            table.addCell(new Phrase("Prix"));
            table.addCell(new Phrase("Places"));
            table.addCell(new Phrase("Conducteur"));
            table.addCell(new Phrase("Commentaire"));

            for (Covoiturage covoiturage : covoiturages) {
                table.addCell(String.valueOf(covoiturage.getId()));
                table.addCell(covoiturage.getVilleDepart());
                table.addCell(covoiturage.getVilleArrivee());
                table.addCell(covoiturage.getDateDepart().format(PDF_DATE_FORMAT));
                table.addCell(covoiturage.getHeureDepart().format(PDF_TIME_FORMAT));
                table.addCell(PRICE_FORMAT.format(covoiturage.getPrixParPlace()));
                table.addCell(String.valueOf(covoiturage.getNbPlaces()));
                table.addCell(String.valueOf(covoiturage.getConducteurId()));
                table.addCell(covoiturage.getCommentaire() == null ? "" : covoiturage.getCommentaire());
            }

            document.add(table);
        } catch (DocumentException exception) {
            throw new IOException("Impossible de generer le PDF.", exception);
        } finally {
            document.close();
        }
    }

    private String formatDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "Aucun depart disponible";
        }

        LocalDate date = dateTime.toLocalDate();
        LocalTime time = dateTime.toLocalTime();
        return date.format(PDF_DATE_FORMAT) + " " + time.format(PDF_TIME_FORMAT);
    }

    public static class CovoiturageStatistiques {
        private final int totalCovoiturages;
        private final int totalPlaces;
        private final double prixMoyen;
        private final double prixMinimum;
        private final double prixMaximum;
        private final long totalConducteurs;
        private final LocalDateTime prochainDepart;

        public CovoiturageStatistiques(int totalCovoiturages,
                                       int totalPlaces,
                                       double prixMoyen,
                                       double prixMinimum,
                                       double prixMaximum,
                                       long totalConducteurs,
                                       LocalDateTime prochainDepart) {
            this.totalCovoiturages = totalCovoiturages;
            this.totalPlaces = totalPlaces;
            this.prixMoyen = prixMoyen;
            this.prixMinimum = prixMinimum;
            this.prixMaximum = prixMaximum;
            this.totalConducteurs = totalConducteurs;
            this.prochainDepart = prochainDepart;
        }

        public int getTotalCovoiturages() {
            return totalCovoiturages;
        }

        public int getTotalPlaces() {
            return totalPlaces;
        }

        public double getPrixMoyen() {
            return prixMoyen;
        }

        public double getPrixMinimum() {
            return prixMinimum;
        }

        public double getPrixMaximum() {
            return prixMaximum;
        }

        public long getTotalConducteurs() {
            return totalConducteurs;
        }

        public LocalDateTime getProchainDepart() {
            return prochainDepart;
        }
    }
}
