package com.rentall.covoiturage.models;

import java.time.LocalDate;
import java.time.LocalTime;

public class Covoiturage {
    private long id;
    private String villeDepart;
    private String villeArrivee;
    private LocalDate dateDepart;
    private LocalTime heureDepart;
    private double prixParPlace;
    private int nbPlaces;
    private String commentaire;
    private int conducteurId;

    public Covoiturage() {
    }

    public Covoiturage(String villeDepart,
                       String villeArrivee,
                       LocalDate dateDepart,
                       LocalTime heureDepart,
                       double prixParPlace,
                       int nbPlaces,
                       String commentaire,
                       int conducteurId) {
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.dateDepart = dateDepart;
        this.heureDepart = heureDepart;
        this.prixParPlace = prixParPlace;
        this.nbPlaces = nbPlaces;
        this.commentaire = commentaire;
        this.conducteurId = conducteurId;
    }

    public Covoiturage(long id,
                       String villeDepart,
                       String villeArrivee,
                       LocalDate dateDepart,
                       LocalTime heureDepart,
                       double prixParPlace,
                       int nbPlaces,
                       String commentaire,
                       int conducteurId) {
        this.id = id;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.dateDepart = dateDepart;
        this.heureDepart = heureDepart;
        this.prixParPlace = prixParPlace;
        this.nbPlaces = nbPlaces;
        this.commentaire = commentaire;
        this.conducteurId = conducteurId;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVilleDepart() {
        return villeDepart;
    }

    public void setVilleDepart(String villeDepart) {
        this.villeDepart = villeDepart;
    }

    public String getVilleArrivee() {
        return villeArrivee;
    }

    public void setVilleArrivee(String villeArrivee) {
        this.villeArrivee = villeArrivee;
    }

    public LocalDate getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(LocalDate dateDepart) {
        this.dateDepart = dateDepart;
    }

    public LocalTime getHeureDepart() {
        return heureDepart;
    }

    public void setHeureDepart(LocalTime heureDepart) {
        this.heureDepart = heureDepart;
    }

    public double getPrixParPlace() {
        return prixParPlace;
    }

    public void setPrixParPlace(double prixParPlace) {
        this.prixParPlace = prixParPlace;
    }

    public int getNbPlaces() {
        return nbPlaces;
    }

    public void setNbPlaces(int nbPlaces) {
        this.nbPlaces = nbPlaces;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    public int getConducteurId() {
        return conducteurId;
    }

    public void setConducteurId(int conducteurId) {
        this.conducteurId = conducteurId;
    }
}

