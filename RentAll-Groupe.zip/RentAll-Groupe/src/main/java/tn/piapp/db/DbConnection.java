package tn.piapp.db;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;

public class DbConnection {

    private static DbConnection instance;
    private Connection connection;

    private static final String DB_NAME = "pidev_amine";
    private static final String JDBC_OPTIONS = "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String SERVER_URL = "jdbc:mysql://127.0.0.1:3306/" + JDBC_OPTIONS;
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/" + DB_NAME + JDBC_OPTIONS;
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private DbConnection() throws SQLException {
        ensureDatabaseExists();
        connect();
        ensureSchema();
    }

    public static DbConnection getInstance() throws SQLException {
        if (instance == null) {
            instance = new DbConnection();
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            connect();
        }
        return connection;
    }

    private void connect() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static void ensureDatabaseExists() throws SQLException {
        try (Connection serverConnection = DriverManager.getConnection(SERVER_URL, USER, PASSWORD);
             Statement statement = serverConnection.createStatement()) {
            statement.executeUpdate("CREATE DATABASE IF NOT EXISTS `" + DB_NAME + "` "
                    + "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }
    }

    private void ensureSchema() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS `user` (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(150) NULL,
                        nom VARCHAR(100) NULL,
                        prenom VARCHAR(100) NULL,
                        email VARCHAR(180) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL,
                        role VARCHAR(50) NULL,
                        roles LONGTEXT NOT NULL,
                        status VARCHAR(30) NULL,
                        account_status VARCHAR(30) NOT NULL DEFAULT 'active',
                        is_verified TINYINT(1) NOT NULL DEFAULT 1,
                        phone VARCHAR(30) NULL,
                        profile_image VARCHAR(255) NULL,
                        session_token VARCHAR(255) NULL,
                        host_request_date DATETIME NULL,
                        confirmation_token VARCHAR(255) NULL,
                        confirmation_token_expires DATETIME NULL,
                        reset_sms_code VARCHAR(10) NULL,
                        reset_sms_expires DATETIME NULL,
                        oauth_provider VARCHAR(30) NULL,
                        oauth_id VARCHAR(100) NULL,
                        selfie_image VARCHAR(255) NULL,
                        identity_document_image VARCHAR(255) NULL,
                        face_verified_at DATETIME NULL,
                        created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS category (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(120) NOT NULL,
                        type VARCHAR(30) NOT NULL,
                        created_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        UNIQUE KEY uk_category_name_type (name, type)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS service (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(160) NOT NULL,
                        description TEXT NULL,
                        base_price DECIMAL(10,2) NOT NULL DEFAULT 0,
                        duration_minutes INT NOT NULL DEFAULT 0,
                        location VARCHAR(255) NULL,
                        is_active TINYINT(1) NOT NULL DEFAULT 0,
                        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        host_id INT NULL,
                        image_name VARCHAR(255) NULL,
                        category_id INT NULL,
                        latitude DOUBLE NULL,
                        longitude DOUBLE NULL,
                        INDEX idx_service_host (host_id),
                        INDEX idx_service_category (category_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS tool (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(160) NOT NULL,
                        description TEXT NULL,
                        price_per_day DECIMAL(10,2) NOT NULL DEFAULT 0,
                        stock_quantity INT NOT NULL DEFAULT 0,
                        location VARCHAR(255) NULL,
                        is_active TINYINT(1) NOT NULL DEFAULT 0,
                        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        host_id INT NULL,
                        image_name VARCHAR(255) NULL,
                        category_id INT NULL,
                        latitude DOUBLE NULL,
                        longitude DOUBLE NULL,
                        INDEX idx_tool_host (host_id),
                        INDEX idx_tool_category (category_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);

            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS covoiturages (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        ville_depart VARCHAR(120) NOT NULL,
                        ville_arrivee VARCHAR(120) NOT NULL,
                        date_depart DATE NOT NULL,
                        heure_depart TIME NOT NULL,
                        prix_par_place DOUBLE NOT NULL,
                        nb_places INT NOT NULL,
                        commentaire VARCHAR(255) NULL,
                        conducteur_id INT NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);
        }

        ensureUserColumns();
        ensureCategoryColumns();
        ensureListingColumns("service", "base_price", "DECIMAL(10,2) NULL", "duration_minutes", "INT NULL");
        ensureListingColumns("tool", "price_per_day", "DECIMAL(10,2) NULL", "stock_quantity", "INT NULL");
        ensureCovoiturageColumns();
        seedDefaults();
    }

    private void ensureUserColumns() throws SQLException {
        ensureColumn("user", "name", "VARCHAR(150) NULL");
        ensureColumn("user", "nom", "VARCHAR(100) NULL");
        ensureColumn("user", "prenom", "VARCHAR(100) NULL");
        ensureColumn("user", "email", "VARCHAR(180) NULL");
        ensureColumn("user", "password", "VARCHAR(255) NULL");
        ensureColumn("user", "role", "VARCHAR(50) NULL");
        ensureColumn("user", "roles", "LONGTEXT NULL");
        ensureColumn("user", "status", "VARCHAR(30) NULL");
        ensureColumn("user", "account_status", "VARCHAR(30) NOT NULL DEFAULT 'active'");
        ensureColumn("user", "is_verified", "TINYINT(1) NOT NULL DEFAULT 1");
        ensureColumn("user", "phone", "VARCHAR(30) NULL");
        ensureColumn("user", "profile_image", "VARCHAR(255) NULL");
        ensureColumn("user", "session_token", "VARCHAR(255) NULL");
        ensureColumn("user", "host_request_date", "DATETIME NULL");
        ensureColumn("user", "confirmation_token", "VARCHAR(255) NULL");
        ensureColumn("user", "confirmation_token_expires", "DATETIME NULL");
        ensureColumn("user", "reset_sms_code", "VARCHAR(10) NULL");
        ensureColumn("user", "reset_sms_expires", "DATETIME NULL");
        ensureColumn("user", "oauth_provider", "VARCHAR(30) NULL");
        ensureColumn("user", "oauth_id", "VARCHAR(100) NULL");
        ensureColumn("user", "selfie_image", "VARCHAR(255) NULL");
        ensureColumn("user", "identity_document_image", "VARCHAR(255) NULL");
        ensureColumn("user", "face_verified_at", "DATETIME NULL");
        ensureColumn("user", "created_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP");
        ensureColumn("user", "updated_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    }

    private void ensureCategoryColumns() throws SQLException {
        ensureColumn("category", "name", "VARCHAR(120) NULL");
        ensureColumn("category", "type", "VARCHAR(30) NULL");
        ensureColumn("category", "created_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP");
        ensureColumn("category", "updated_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    }

    private void ensureListingColumns(String table, String priceColumn, String priceDefinition,
                                      String quantityColumn, String quantityDefinition) throws SQLException {
        ensureColumn(table, "name", "VARCHAR(160) NULL");
        ensureColumn(table, "description", "TEXT NULL");
        ensureColumn(table, priceColumn, priceDefinition);
        ensureColumn(table, quantityColumn, quantityDefinition);
        ensureColumn(table, "location", "VARCHAR(255) NULL");
        ensureColumn(table, "is_active", "TINYINT(1) NOT NULL DEFAULT 0");
        ensureColumn(table, "created_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP");
        ensureColumn(table, "updated_at", "DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        ensureColumn(table, "host_id", "INT NULL");
        ensureColumn(table, "image_name", "VARCHAR(255) NULL");
        ensureColumn(table, "category_id", "INT NULL");
        ensureColumn(table, "latitude", "DOUBLE NULL");
        ensureColumn(table, "longitude", "DOUBLE NULL");
    }

    private void ensureCovoiturageColumns() throws SQLException {
        ensureColumn("covoiturages", "ville_depart", "VARCHAR(120) NULL");
        ensureColumn("covoiturages", "ville_arrivee", "VARCHAR(120) NULL");
        ensureColumn("covoiturages", "date_depart", "DATE NULL");
        ensureColumn("covoiturages", "heure_depart", "TIME NULL");
        ensureColumn("covoiturages", "prix_par_place", "DOUBLE NULL");
        ensureColumn("covoiturages", "nb_places", "INT NULL");
        ensureColumn("covoiturages", "commentaire", "VARCHAR(255) NULL");
        ensureColumn("covoiturages", "conducteur_id", "INT NULL");
    }

    private void ensureColumn(String table, String column, String definition) throws SQLException {
        if (columnExists(table, column)) {
            return;
        }

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("ALTER TABLE `" + table + "` ADD COLUMN `" + column + "` " + definition);
        }
    }

    private boolean columnExists(String table, String column) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        try (ResultSet columns = metaData.getColumns(connection.getCatalog(), null, table, column)) {
            if (columns.next()) {
                return true;
            }
        }

        try (ResultSet columns = metaData.getColumns(connection.getCatalog(), null,
                table.toUpperCase(Locale.ROOT), column.toUpperCase(Locale.ROOT))) {
            return columns.next();
        }
    }

    private void seedDefaults() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    INSERT INTO category (name, type, created_at)
                    SELECT name, type, NOW()
                    FROM (
                        SELECT 'Plomberie' AS name, 'service' AS type
                        UNION ALL SELECT 'Electricite', 'service'
                        UNION ALL SELECT 'Nettoyage', 'service'
                        UNION ALL SELECT 'Jardinage', 'service'
                        UNION ALL SELECT 'Perceuse', 'tool'
                        UNION ALL SELECT 'Echelle', 'tool'
                        UNION ALL SELECT 'Tondeuse', 'tool'
                        UNION ALL SELECT 'Nettoyeur haute pression', 'tool'
                    ) default_categories
                    WHERE NOT EXISTS (
                        SELECT 1
                        FROM category c
                        WHERE c.name = default_categories.name AND c.type = default_categories.type
                    )
                    """);

            statement.executeUpdate("""
                    INSERT INTO `user`
                        (name, nom, prenom, email, password, role, roles, status,
                         account_status, is_verified, created_at, updated_at)
                    SELECT 'Test Admin', 'Admin', 'Test', 'test@example.com',
                           '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
                           'ROLE_ADMIN', '["ROLE_ADMIN"]', 'ACTIVE', 'active', 1, NOW(), NOW()
                    WHERE NOT EXISTS (SELECT 1 FROM `user` WHERE email = 'test@example.com')
                    """);
        }
    }
}
