package tn.piapp.ui.covoiturage;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import com.rentall.covoiturage.models.Covoiturage;
import com.rentall.covoiturage.services.CovoiturageService;

import com.rentall.covoiturage.utils.InputValidator;
import com.rentall.covoiturage.utils.ViewNavigator;

import java.io.IOException;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;

public class ModifierCovoiturageController {
    private final CovoiturageService covoiturageService = new CovoiturageService();
    private Covoiturage covoiturageSelectionne;

    @FXML
    private Label covoiturageIdLabel;

    @FXML
    private TextField conducteurIdField;

    @FXML
    private TextField villeDepartField;

    @FXML
    private TextField villeArriveeField;

    @FXML
    private DatePicker dateDepartPicker;

    @FXML
    private TextField heureDepartField;

    @FXML
    private TextField prixParPlaceField;

    @FXML
    private Spinner<Integer> nbPlacesSpinner;

    @FXML
    private TextField commentaireField;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        SpinnerValueFactory.IntegerSpinnerValueFactory valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 8, 1);
        nbPlacesSpinner.setValueFactory(valueFactory);
        heureDepartField.setText("08:00");
        configurerValidations();
    }

    private void configurerValidations() {
        conducteurIdField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerConducteurId(newVal);
                conducteurIdField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                conducteurIdField.setStyle("");
            }
        });

        villeDepartField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerVille(newVal, "La ville de depart");
                villeDepartField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                villeDepartField.setStyle("");
            }
        });

        villeArriveeField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerVille(newVal, "La ville d'arrivee");
                villeArriveeField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                villeArriveeField.setStyle("");
            }
        });

        dateDepartPicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                InputValidator.ValidationResult result = InputValidator.validerDateDepart(newVal, false);
                dateDepartPicker.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                dateDepartPicker.setStyle("");
            }
        });

        heureDepartField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerHeure(newVal, "L'heure de depart");
                heureDepartField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                heureDepartField.setStyle("");
            }
        });

        prixParPlaceField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerPrix(newVal, "Le prix par place");
                prixParPlaceField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                prixParPlaceField.setStyle("");
            }
        });

        commentaireField.textProperty().addListener((obs, oldVal, newVal) -> {
            InputValidator.ValidationResult result = InputValidator.validerCommentaire(newVal);
            commentaireField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
        });
    }

    public void setCovoiturage(Covoiturage covoiturage) {
        this.covoiturageSelectionne = new Covoiturage(
                covoiturage.getId(),
                covoiturage.getVilleDepart(),
                covoiturage.getVilleArrivee(),
                covoiturage.getDateDepart(),
                covoiturage.getHeureDepart(),
                covoiturage.getPrixParPlace(),
                covoiturage.getNbPlaces(),
                covoiturage.getCommentaire(),
                covoiturage.getConducteurId()
        );

        covoiturageIdLabel.setText("Covoiturage #" + covoiturage.getId());
        conducteurIdField.setText(String.valueOf(covoiturage.getConducteurId()));
        villeDepartField.setText(covoiturage.getVilleDepart());
        villeArriveeField.setText(covoiturage.getVilleArrivee());
        dateDepartPicker.setValue(covoiturage.getDateDepart());
        heureDepartField.setText(covoiturage.getHeureDepart().format(DateTimeFormatter.ofPattern("HH:mm")));
        prixParPlaceField.setText(String.valueOf(covoiturage.getPrixParPlace()));
        nbPlacesSpinner.getValueFactory().setValue(covoiturage.getNbPlaces());
        commentaireField.setText(covoiturage.getCommentaire() == null ? "" : covoiturage.getCommentaire());

        afficherSucces("Covoiturage charge. Tu peux maintenant le modifier.");
    }

    @FXML
    private void enregistrerModification() {
        if (covoiturageSelectionne == null) {
            afficherErreur("Aucun covoiturage n'a ete selectionne.");
            return;
        }

        try {
            InputValidator.ValidationResult validation = InputValidator.validerCovoiturageComplet(
                    conducteurIdField.getText(),
                    villeDepartField.getText(),
                    villeArriveeField.getText(),
                    dateDepartPicker.getValue(),
                    heureDepartField.getText(),
                    prixParPlaceField.getText(),
                    nbPlacesSpinner.getValue(),
                    commentaireField.getText()
            );

            if (!validation.isValid()) {
                afficherErreur(validation.getErrorMessage());
                return;
            }

            InputValidator.CovoiturageValues values = (InputValidator.CovoiturageValues) validation.getValue();
            covoiturageSelectionne.setConducteurId(values.getConducteurId());
            covoiturageSelectionne.setVilleDepart(values.getVilleDepart());
            covoiturageSelectionne.setVilleArrivee(values.getVilleArrivee());
            covoiturageSelectionne.setDateDepart(values.getDateDepart());
            covoiturageSelectionne.setHeureDepart(values.getHeureDepart());
            covoiturageSelectionne.setPrixParPlace(values.getPrixParPlace());
            covoiturageSelectionne.setNbPlaces(values.getNbPlaces());
            covoiturageSelectionne.setCommentaire(values.getCommentaire());

            covoiturageService.modifierCovoiturage(covoiturageSelectionne);
            afficherSucces(CovoiturageService.SUCCESS_MESSAGE + " Covoiturage modifie.");
        } catch (SQLException exception) {
            afficherErreur("Impossible de modifier le covoiturage : " + exception.getMessage());
        }
    }

    @FXML
    private void retourListe() {
        try {
            ViewNavigator.navigate(statusLabel, "/tn/piapp/ui/covoiturage/views/annonces-covoiturage-view.fxml");
        } catch (IOException exception) {
            afficherErreur("Impossible de revenir a la liste : " + exception.getMessage());
        }
    }

    private void afficherSucces(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-error");
        if (!statusLabel.getStyleClass().contains("status-success")) {
            statusLabel.getStyleClass().add("status-success");
        }
    }

    private void afficherErreur(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-success");
        if (!statusLabel.getStyleClass().contains("status-error")) {
            statusLabel.getStyleClass().add("status-error");
        }
    }
}

