package tn.piapp.ui.covoiturage;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import com.rentall.covoiturage.models.Covoiturage;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;

public class MapCovoiturageController {
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    private String villeDepart;
    private String villeArrivee;

    @FXML
    private Label pageSubtitleLabel;

    @FXML
    private Label trajetLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private WebView mapWebView;

    @FXML
    public void initialize() {
        WebEngine engine = mapWebView.getEngine();
        engine.setJavaScriptEnabled(true);
    }

    public void setCovoiturage(Covoiturage covoiturage) {
        this.villeDepart = covoiturage.getVilleDepart();
        this.villeArrivee = covoiturage.getVilleArrivee();

        pageSubtitleLabel.setText("Trajet de " + villeDepart + " vers " + villeArrivee);
        trajetLabel.setText(
                "Depart: " + villeDepart +
                " | Arrivee: " + villeArrivee +
                " | Date: " + covoiturage.getDateDepart().format(DATE_FORMAT) +
                " | Heure: " + covoiturage.getHeureDepart().format(TIME_FORMAT)
        );

        chargerCarte();
    }

    public void setTrajet(String villeDepart, String villeArrivee) {
        this.villeDepart = villeDepart == null ? "" : villeDepart.trim();
        this.villeArrivee = villeArrivee == null ? "" : villeArrivee.trim();

        pageSubtitleLabel.setText("Apercu du trajet avant enregistrement");
        trajetLabel.setText("Depart: " + this.villeDepart + " | Arrivee: " + this.villeArrivee);

        chargerCarte();
    }

    @FXML
    private void actualiserCarte() {
        if (villeDepart == null || villeDepart.isBlank() || villeArrivee == null || villeArrivee.isBlank()) {
            afficherErreur("Aucun covoiturage n'est charge.");
            return;
        }

        chargerCarte();
    }

    @FXML
    private void ouvrirDansNavigateur() {
        if (villeDepart == null || villeDepart.isBlank() || villeArrivee == null || villeArrivee.isBlank()) {
            afficherErreur("Aucun covoiturage n'est charge.");
            return;
        }

        if (!Desktop.isDesktopSupported()) {
            afficherErreur("Ouverture du navigateur non supportee sur cette machine.");
            return;
        }

        try {
            String origin = URLEncoder.encode(villeDepart, StandardCharsets.UTF_8);
            String destination = URLEncoder.encode(villeArrivee, StandardCharsets.UTF_8);
            URI uri = URI.create("https://www.google.com/maps/dir/?api=1&origin=" + origin + "&destination=" + destination);
            Desktop.getDesktop().browse(uri);
            afficherSucces("Itineraire ouvert dans le navigateur.");
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir le navigateur : " + exception.getMessage());
        }
    }

    @FXML
    private void fermerFenetre() {
        Stage stage = (Stage) statusLabel.getScene().getWindow();
        stage.close();
    }

    private void chargerCarte() {
        mapWebView.getEngine().loadContent(construireHtmlCarte(villeDepart, villeArrivee));
        afficherSucces("Carte chargee. Une connexion internet est necessaire pour les tuiles et l'itineraire.");
    }

    private String construireHtmlCarte(String depart, String arrivee) {
        String safeDepart = escapeJs(depart);
        String safeArrivee = escapeJs(arrivee);

        return """
                <!DOCTYPE html>
                <html lang="fr">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Carte Covoiturage</title>
                    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                    <style>
                        html, body, #map {
                            height: 100%%;
                            width: 100%%;
                            margin: 0;
                            font-family: Segoe UI, sans-serif;
                            background: linear-gradient(to bottom right, #f7f4ff, #edf7ff);
                        }
                        .map-note {
                            position: absolute;
                            top: 12px;
                            left: 50px;
                            z-index: 1000;
                            background: rgba(255, 255, 255, 0.92);
                            padding: 10px 14px;
                            border-radius: 12px;
                            color: #25304f;
                            font-weight: 600;
                            box-shadow: 0 8px 20px rgba(31, 41, 55, 0.12);
                        }
                    </style>
                </head>
                <body>
                    <div class="map-note">Chargement de la carte et de l'itineraire...</div>
                    <div id="map"></div>
                    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                    <script>
                        const depart = '%s';
                        const arrivee = '%s';

                        const map = L.map('map').setView([34.0, 9.0], 6);
                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                            maxZoom: 19,
                            attribution: '&copy; OpenStreetMap contributors'
                        }).addTo(map);

                        async function searchCity(city) {
                            const url = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=' + encodeURIComponent(city);
                            const response = await fetch(url, {
                                headers: {
                                    'Accept': 'application/json'
                                }
                            });

                            if (!response.ok) {
                                throw new Error('Geocodage impossible pour ' + city);
                            }

                            const data = await response.json();
                            if (!data.length) {
                                throw new Error('Ville introuvable : ' + city);
                            }

                            return {
                                lat: parseFloat(data[0].lat),
                                lon: parseFloat(data[0].lon),
                                label: data[0].display_name
                            };
                        }

                        async function drawRoute(origin, destination) {
                            const routeUrl =
                                'https://router.project-osrm.org/route/v1/driving/' +
                                origin.lon + ',' + origin.lat + ';' + destination.lon + ',' + destination.lat +
                                '?overview=full&geometries=geojson';

                            const response = await fetch(routeUrl);
                            if (!response.ok) {
                                throw new Error('Itineraire indisponible');
                            }

                            const data = await response.json();
                            if (!data.routes || !data.routes.length) {
                                throw new Error('Aucun itineraire trouve');
                            }

                            const route = data.routes[0].geometry.coordinates.map(coord => [coord[1], coord[0]]);
                            const polyline = L.polyline(route, {
                                color: '#7c3aed',
                                weight: 6,
                                opacity: 0.85
                            }).addTo(map);

                            map.fitBounds(polyline.getBounds(), { padding: [35, 35] });
                        }

                        async function init() {
                            try {
                                const origin = await searchCity(depart);
                                const destination = await searchCity(arrivee);

                                L.marker([origin.lat, origin.lon]).addTo(map)
                                    .bindPopup('<strong>Depart</strong><br>' + origin.label);
                                L.marker([destination.lat, destination.lon]).addTo(map)
                                    .bindPopup('<strong>Arrivee</strong><br>' + destination.label);

                                await drawRoute(origin, destination);
                                document.querySelector('.map-note').textContent = 'Itineraire affiche entre ' + depart + ' et ' + arrivee + '.';
                            } catch (error) {
                                document.querySelector('.map-note').textContent = error.message;
                            }
                        }

                        init();
                    </script>
                </body>
                </html>
                """.formatted(safeDepart, safeArrivee);
    }

    private String escapeJs(String value) {
        return value
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\r", " ")
                .replace("\n", " ");
    }

    private void afficherSucces(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-error");
        if (!statusLabel.getStyleClass().contains("status-success")) {
            statusLabel.getStyleClass().add("status-success");
        }
    }

    private void afficherErreur(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-success");
        if (!statusLabel.getStyleClass().contains("status-error")) {
            statusLabel.getStyleClass().add("status-error");
        }
    }
}
