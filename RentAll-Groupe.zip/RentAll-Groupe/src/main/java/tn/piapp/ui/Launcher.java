package tn.piapp.ui;

/**
 * Classe de lancement intermediaire qui n'etend pas Application.
 *
 * Pourquoi ?
 *   Quand on lance directement une classe qui etend javafx.application.Application
 *   et que JavaFX n'est PAS sur le module path (cas d'un projet sans module-info.java),
 *   le JDK refuse de demarrer avec :
 *      "Error: JavaFX runtime components are missing"
 *
 *   En lancant Launcher.main(), Java ne fait pas ce check car Launcher n'est pas
 *   une sous-classe de Application. Launcher appelle ensuite MainApp.main() qui
 *   demarre JavaFX normalement.
 */
public class Launcher {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}
