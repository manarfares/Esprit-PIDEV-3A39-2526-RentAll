package tn.piapp.ui.covoiturage;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import tn.piapp.ui.IntegratedCovoiturageView;
import com.rentall.covoiturage.models.Covoiturage;
import com.rentall.covoiturage.services.CovoiturageService;

import com.rentall.covoiturage.utils.InputValidator;
import com.rentall.covoiturage.utils.ViewNavigator;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;

public class AnnoncesCovoiturageController {
    private static final DateTimeFormatter UI_DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter UI_TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("0.00");

    private final CovoiturageService covoiturageService = new CovoiturageService();

    @FXML
    private ListView<Covoiturage> covoituragesListView;

    @FXML
    private Label statusLabel;

    @FXML
    private TextField heureSouhaiteeField;

    @FXML
    private TextField budgetMaxField;

    @FXML
    public void initialize() {
        configurerListeMarketplace();
        try {
            chargerCovoiturages();
        } catch (SQLException exception) {
            afficherErreur("Impossible de charger les annonces : " + exception.getMessage());
        }
    }

    private void configurerListeMarketplace() {
        Label placeholder = new Label("Aucune offre pour le moment.");
        placeholder.getStyleClass().add("page-subtitle");
        covoituragesListView.setPlaceholder(placeholder);

        covoituragesListView.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(Covoiturage item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                    return;
                }

                Label routeLabel = new Label(item.getVilleDepart() + " -> " + item.getVilleArrivee());
                routeLabel.getStyleClass().add("offer-route");

                Label scheduleLabel = new Label(
                        item.getDateDepart().format(UI_DATE_FORMAT) + "  -  " +
                                item.getHeureDepart().format(UI_TIME_FORMAT)
                );
                scheduleLabel.getStyleClass().add("offer-meta");

                Label driverBadge = createBadge("Conducteur #" + item.getConducteurId(), "offer-chip");
                Label seatsBadge = createBadge(item.getNbPlaces() + " place(s)", "offer-chip");
                Label priceBadge = createBadge(PRICE_FORMAT.format(item.getPrixParPlace()) + " DT / place", "offer-price");

                HBox badgesRow = new HBox(8, driverBadge, seatsBadge, priceBadge);
                badgesRow.setAlignment(Pos.CENTER_LEFT);

                String commentText = item.getCommentaire() == null || item.getCommentaire().isBlank()
                        ? "Sans commentaire. Trajet pret a etre reserve."
                        : item.getCommentaire();
                Label commentLabel = new Label(commentText);
                commentLabel.getStyleClass().add("offer-comment");
                commentLabel.setWrapText(true);

                Label offerIdLabel = new Label("Offre #" + item.getId());
                offerIdLabel.getStyleClass().add("offer-id");

                Label sideNoteLabel = new Label("Cliquer pour selectionner");
                sideNoteLabel.getStyleClass().add("offer-side-note");

                VBox contentBox = new VBox(8, routeLabel, scheduleLabel, badgesRow, commentLabel);
                contentBox.setFillWidth(true);

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);

                VBox sideBox = new VBox(8, offerIdLabel, sideNoteLabel);
                sideBox.setAlignment(Pos.TOP_RIGHT);
                sideBox.getStyleClass().add("offer-side");

                HBox card = new HBox(16, contentBox, spacer, sideBox);
                card.setAlignment(Pos.TOP_LEFT);
                card.setPadding(new Insets(18, 20, 18, 20));
                card.getStyleClass().add("offer-card");
                card.setOnMouseClicked(event -> listView.getSelectionModel().select(item));

                setText(null);
                setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                setGraphic(card);
            }
        });
    }

    @FXML
    private void actualiserListe() {
        try {
            chargerCovoiturages();
        } catch (SQLException exception) {
            afficherErreur("Impossible d'actualiser la liste : " + exception.getMessage());
        }
    }

    @FXML
    private void reserverCovoiturage() {
        Covoiturage selection = covoituragesListView.getSelectionModel().getSelectedItem();
        if (selection == null) {
            afficherErreur("Selectionne d'abord une annonce a reserver.");
            return;
        }

        try {
            covoiturageService.reserverCovoiturage(selection.getId());
            afficherMessageSucces(CovoiturageService.SUCCESS_MESSAGE + " Reservation enregistree.");
            chargerCovoiturages();
        } catch (SQLException exception) {
            afficherErreur(exception.getMessage());
        }
    }

    @FXML
    private void supprimerCovoiturage() {
        Covoiturage selection = covoituragesListView.getSelectionModel().getSelectedItem();
        if (selection == null) {
            afficherErreur("Selectionne d'abord un covoiturage a supprimer.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer le covoiturage ?");
        alert.setContentText("Voulez-vous vraiment supprimer l'offre de " +
                selection.getVilleDepart() + " vers " + selection.getVilleArrivee() + " ?");

        var result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                covoiturageService.supprimerCovoiturage(selection.getId());
                afficherMessageSucces(CovoiturageService.SUCCESS_MESSAGE + " Covoiturage supprime.");
                chargerCovoiturages();
            } catch (SQLException exception) {
                afficherErreur("Impossible de supprimer le covoiturage : " + exception.getMessage());
            }
        }
    }

    @FXML
    private void ouvrirPageModification() {
        Covoiturage selection = covoituragesListView.getSelectionModel().getSelectedItem();
        if (selection == null) {
            afficherErreur("Selectionne d'abord un covoiturage a modifier.");
            return;
        }

        try {
            ViewNavigator.navigate(
                    statusLabel,
                    "/tn/piapp/ui/covoiturage/views/edit-covoiturage-view.fxml",
                    controller -> ((ModifierCovoiturageController) controller).setCovoiturage(selection)
            );
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir la page de modification : " + exception.getMessage());
        }
    }

    @FXML
    private void ouvrirMaps() {
        Covoiturage selection = covoituragesListView.getSelectionModel().getSelectedItem();
        if (selection == null) {
            afficherErreur("Selectionne d'abord un covoiturage pour afficher la carte.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/views/map-covoiturage-view.fxml"));
            Parent root = loader.load();
            MapCovoiturageController controller = loader.getController();
            controller.setCovoiturage(selection);

            Stage stage = new Stage();
            Scene scene = new Scene(root, 1180, 760);
            scene.getStylesheets().add(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/styles/covoiturage.css").toExternalForm());
            stage.setTitle("Maps - " + selection.getVilleDepart() + " -> " + selection.getVilleArrivee());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(statusLabel.getScene().getWindow());
            stage.setScene(scene);
            stage.show();
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir Maps : " + exception.getMessage());
        }
    }

    @FXML
    private void afficherStatistiques() {
        try {
            FXMLLoader loader = new FXMLLoader(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/views/statistiques-covoiturage-view.fxml"));
            Parent root = loader.load();
            StatistiquesCovoiturageController controller = loader.getController();
            controller.chargerStatistiques();

            Stage stage = new Stage();
            Scene scene = new Scene(root, 1180, 760);
            scene.getStylesheets().add(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/styles/covoiturage.css").toExternalForm());
            stage.setTitle("Statistiques Covoiturage");
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(statusLabel.getScene().getWindow());
            stage.setScene(scene);
            stage.show();
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir les statistiques : " + exception.getMessage());
        }
    }

    @FXML
    private void exporterPdf() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Exporter les covoiturages en PDF");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF", "*.pdf"));
        fileChooser.setInitialFileName("rapport-covoiturages.pdf");

        File selectedFile = fileChooser.showSaveDialog(statusLabel.getScene().getWindow());
        if (selectedFile == null) {
            afficherErreur("Export PDF annule.");
            return;
        }

        try {
            covoiturageService.exporterEnPdf(selectedFile.getAbsolutePath());
            afficherMessageSucces("PDF exporte avec succes : " + selectedFile.getName());
        } catch (SQLException | IOException exception) {
            afficherErreur("Impossible d'exporter le PDF : " + exception.getMessage());
        }
    }

    @FXML
    private void recommanderCovoiturageIa() {
        List<Covoiturage> offres = covoituragesListView.getItems();
        if (offres == null || offres.isEmpty()) {
            afficherErreur("Aucune offre disponible pour calculer une recommandation IA.");
            return;
        }

        LocalTime heureSouhaitee = null;
        String heureInput = heureSouhaiteeField == null ? "" : heureSouhaiteeField.getText();
        if (heureInput != null && !heureInput.isBlank()) {
            InputValidator.ValidationResult heureResult = InputValidator.validerHeure(heureInput, "Heure souhaitee");
            if (!heureResult.isValid()) {
                afficherErreur(heureResult.getErrorMessage());
                return;
            }
            heureSouhaitee = LocalTime.parse((String) heureResult.getValue(), DateTimeFormatter.ofPattern("HH:mm"));
        }

        Double budgetMax = null;
        String budgetInput = budgetMaxField == null ? "" : budgetMaxField.getText();
        if (budgetInput != null && !budgetInput.isBlank()) {
            InputValidator.ValidationResult budgetResult = InputValidator.validerPrix(budgetInput, "Budget max");
            if (!budgetResult.isValid()) {
                afficherErreur(budgetResult.getErrorMessage());
                return;
            }
            budgetMax = (double) budgetResult.getValue();
        }

        final LocalTime heureSouhaiteeFinale = heureSouhaitee;
        final Double budgetMaxFinal = budgetMax;

        Covoiturage meilleureOffre = offres.stream()
                .filter(offre -> offre.getNbPlaces() > 0)
                .max(Comparator.comparingDouble(offre -> calculerScoreIa(offre, heureSouhaiteeFinale, budgetMaxFinal)))
                .orElse(null);

        if (meilleureOffre == null) {
            afficherErreur("Aucune offre recommandable: verifie les places disponibles et tes filtres.");
            return;
        }

        covoituragesListView.getSelectionModel().select(meilleureOffre);
        covoituragesListView.scrollTo(meilleureOffre);
        double score = calculerScoreIa(meilleureOffre, heureSouhaiteeFinale, budgetMaxFinal);
        afficherMessageSucces("Suggestion IA: offre #" + meilleureOffre.getId() +
                " (" + meilleureOffre.getVilleDepart() + " -> " + meilleureOffre.getVilleArrivee() +
                "), score " + PRICE_FORMAT.format(score) + ".");
    }

    private double calculerScoreIa(Covoiturage offre, LocalTime heureSouhaitee, Double budgetMax) {
        double scorePlaces = Math.min(offre.getNbPlaces(), 8) / 8.0;

        double scorePrix = 1.0;
        if (budgetMax != null) {
            if (offre.getPrixParPlace() > budgetMax) {
                scorePrix = Math.max(0.0, 1.0 - ((offre.getPrixParPlace() - budgetMax) / Math.max(budgetMax, 1.0)));
            } else {
                scorePrix = Math.max(0.0, 1.0 - (offre.getPrixParPlace() / Math.max(budgetMax, 1.0)) * 0.7);
            }
        }

        double scoreHeure = 0.8;
        if (heureSouhaitee != null) {
            long minutesDiff = Math.abs(ChronoUnit.MINUTES.between(heureSouhaitee, offre.getHeureDepart()));
            scoreHeure = Math.max(0.0, 1.0 - (minutesDiff / 300.0));
        } else {
            LocalDateTime depart = LocalDateTime.of(offre.getDateDepart(), offre.getHeureDepart());
            long heuresVersDepart = ChronoUnit.HOURS.between(LocalDateTime.now(), depart);
            if (heuresVersDepart < 0) {
                scoreHeure = 0.0;
            } else {
                scoreHeure = Math.max(0.0, 1.0 - (heuresVersDepart / 72.0));
            }
        }

        // Weighted scoring model: price, schedule match and seat availability.
        return (0.45 * scorePrix) + (0.35 * scoreHeure) + (0.20 * scorePlaces);
    }

    @FXML
    private void ouvrirPublication() {
        try {
            ViewNavigator.navigate(statusLabel, "/tn/piapp/ui/covoiturage/views/covoiturages-view.fxml");
        } catch (IOException exception) {
            afficherErreur("Impossible de revenir au formulaire : " + exception.getMessage());
        }
    }

    private void chargerCovoiturages() throws SQLException {
        List<Covoiturage> covoiturages = covoiturageService.getAllCovoiturages();
        covoituragesListView.setItems(FXCollections.observableArrayList(covoiturages));
        afficherMessageSucces(CovoiturageService.SUCCESS_MESSAGE + " " + covoiturages.size() + " annonce(s) chargee(s).");
    }

    private void afficherMessageSucces(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-error");
        if (!statusLabel.getStyleClass().contains("status-success")) {
            statusLabel.getStyleClass().add("status-success");
        }
    }

    private void afficherErreur(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-success");
        if (!statusLabel.getStyleClass().contains("status-error")) {
            statusLabel.getStyleClass().add("status-error");
        }
    }

    private Label createBadge(String text, String styleClass) {
        Label badge = new Label(text);
        badge.getStyleClass().add(styleClass);
        return badge;
    }
}
