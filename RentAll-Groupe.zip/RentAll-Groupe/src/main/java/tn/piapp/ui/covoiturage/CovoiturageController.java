package tn.piapp.ui.covoiturage;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import tn.piapp.ui.IntegratedCovoiturageView;
import com.rentall.covoiturage.models.Covoiturage;
import com.rentall.covoiturage.services.CovoiturageService;

import com.rentall.covoiturage.utils.InputValidator;
import com.rentall.covoiturage.utils.ViewNavigator;

import java.io.IOException;
import java.sql.SQLException;

public class CovoiturageController {
    private final CovoiturageService covoiturageService = new CovoiturageService();

    @FXML
    private TextField conducteurIdField;

    @FXML
    private TextField villeDepartField;

    @FXML
    private TextField villeArriveeField;

    @FXML
    private DatePicker dateDepartPicker;

    @FXML
    private TextField heureDepartField;

    @FXML
    private TextField prixParPlaceField;

    @FXML
    private Spinner<Integer> nbPlacesSpinner;

    @FXML
    private TextField commentaireField;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        configurerSpinner();
        configurerValidations();

        heureDepartField.setText("08:00");
        conducteurIdField.setText("1");

        try {
            covoiturageService.initialiserBase();
            afficherMessageSucces("Connexion reussie a la base de donnees. Base initialisee.");
        } catch (SQLException exception) {
            afficherErreur("Erreur de connexion a MySQL/XAMPP : " + exception.getMessage());
        }
    }

    private void configurerSpinner() {
        SpinnerValueFactory.IntegerSpinnerValueFactory valueFactory =
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 8, 1);
        nbPlacesSpinner.setValueFactory(valueFactory);
    }

    private void configurerValidations() {
        conducteurIdField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerConducteurId(newVal);
                conducteurIdField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                conducteurIdField.setStyle("");
            }
        });

        villeDepartField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerVille(newVal, "La ville de depart");
                villeDepartField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                villeDepartField.setStyle("");
            }
        });

        villeArriveeField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerVille(newVal, "La ville d'arrivee");
                villeArriveeField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                villeArriveeField.setStyle("");
            }
        });

        dateDepartPicker.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                InputValidator.ValidationResult result = InputValidator.validerDateDepart(newVal, false);
                dateDepartPicker.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                dateDepartPicker.setStyle("");
            }
        });

        heureDepartField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerHeure(newVal, "L'heure de depart");
                heureDepartField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                heureDepartField.setStyle("");
            }
        });

        prixParPlaceField.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                InputValidator.ValidationResult result = InputValidator.validerPrix(newVal, "Le prix par place");
                prixParPlaceField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
            } else {
                prixParPlaceField.setStyle("");
            }
        });

        commentaireField.textProperty().addListener((obs, oldVal, newVal) -> {
            InputValidator.ValidationResult result = InputValidator.validerCommentaire(newVal);
            commentaireField.setStyle(result.isValid() ? "" : "-fx-border-color: red; -fx-border-width: 2px;");
        });
    }

    @FXML
    private void enregistrerCovoiturage() {
        try {
            InputValidator.ValidationResult validation = InputValidator.validerCovoiturageComplet(
                    conducteurIdField.getText(),
                    villeDepartField.getText(),
                    villeArriveeField.getText(),
                    dateDepartPicker.getValue(),
                    heureDepartField.getText(),
                    prixParPlaceField.getText(),
                    nbPlacesSpinner.getValue(),
                    commentaireField.getText()
            );

            if (!validation.isValid()) {
                afficherErreur(validation.getErrorMessage());
                return;
            }

            InputValidator.CovoiturageValues values = (InputValidator.CovoiturageValues) validation.getValue();
            Covoiturage covoiturage = new Covoiturage(
                    values.getVilleDepart(),
                    values.getVilleArrivee(),
                    values.getDateDepart(),
                    values.getHeureDepart(),
                    values.getPrixParPlace(),
                    values.getNbPlaces(),
                    values.getCommentaire(),
                    values.getConducteurId()
            );

            covoiturageService.ajouterCovoiturage(covoiturage);
            afficherMessageSucces(CovoiturageService.SUCCESS_MESSAGE + " Covoiturage ajoute.");
            viderFormulaire();
        } catch (SQLException exception) {
            afficherErreur("Impossible d'ajouter le covoiturage : " + exception.getMessage());
        }
    }

    @FXML
    private void actualiserListe() {
        afficherMessageSucces("Formulaire reinitialise. Ouvre la page Annonces pour voir la liste complete.");
    }

    @FXML
    private void viderFormulaire() {
        conducteurIdField.setText("1");
        villeDepartField.clear();
        villeArriveeField.clear();
        dateDepartPicker.setValue(null);
        heureDepartField.setText("08:00");
        prixParPlaceField.clear();
        nbPlacesSpinner.getValueFactory().setValue(1);
        commentaireField.clear();

        conducteurIdField.setStyle("");
        villeDepartField.setStyle("");
        villeArriveeField.setStyle("");
        dateDepartPicker.setStyle("");
        heureDepartField.setStyle("");
        prixParPlaceField.setStyle("");
        commentaireField.setStyle("");
    }

    @FXML
    private void ouvrirPageAnnonces() {
        try {
            ViewNavigator.navigate(statusLabel, "/tn/piapp/ui/covoiturage/views/annonces-covoiturage-view.fxml");
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir la page des annonces : " + exception.getMessage());
        }
    }

    @FXML
    private void ouvrirPageModification() {
        ouvrirPageAnnonces();
    }

    @FXML
    private void ouvrirMapsDepuisFormulaire() {
        InputValidator.ValidationResult departResult = InputValidator.validerVille(
                villeDepartField.getText(),
                "La ville de depart"
        );
        if (!departResult.isValid()) {
            afficherErreur(departResult.getErrorMessage());
            return;
        }

        InputValidator.ValidationResult arriveeResult = InputValidator.validerVille(
                villeArriveeField.getText(),
                "La ville d'arrivee"
        );
        if (!arriveeResult.isValid()) {
            afficherErreur(arriveeResult.getErrorMessage());
            return;
        }

        String villeDepart = (String) departResult.getValue();
        String villeArrivee = (String) arriveeResult.getValue();
        if (villeDepart.equalsIgnoreCase(villeArrivee)) {
            afficherErreur("La ville de depart et la ville d'arrivee doivent etre differentes.");
            return;
        }

        try {
            ouvrirFenetreMaps(
                    "Maps - Apercu avant ajout",
                    controller -> controller.setTrajet(villeDepart, villeArrivee)
            );
            afficherMessageSucces("Apercu Maps du formulaire ouvert.");
        } catch (IOException exception) {
            afficherErreur("Impossible d'ouvrir la fenetre Maps : " + exception.getMessage());
        }
    }

    private void ouvrirFenetreMaps(String titre, MapsConfigurer configurer) throws IOException {
        FXMLLoader loader = new FXMLLoader(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/views/map-covoiturage-view.fxml"));
        Parent root = loader.load();

        MapCovoiturageController controller = loader.getController();
        configurer.configure(controller);

        Stage stage = new Stage();
        Scene scene = new Scene(root, 1180, 760);
        scene.getStylesheets().add(IntegratedCovoiturageView.class.getResource("/tn/piapp/ui/covoiturage/styles/covoiturage.css").toExternalForm());

        stage.setTitle(titre);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(statusLabel.getScene().getWindow());
        stage.setMinWidth(1080);
        stage.setMinHeight(720);
        stage.setScene(scene);
        stage.show();
    }

    private void afficherMessageSucces(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-error");
        if (!statusLabel.getStyleClass().contains("status-success")) {
            statusLabel.getStyleClass().add("status-success");
        }
    }

    private void afficherErreur(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-success");
        if (!statusLabel.getStyleClass().contains("status-error")) {
            statusLabel.getStyleClass().add("status-error");
        }
    }

    @FunctionalInterface
    private interface MapsConfigurer {
        void configure(MapCovoiturageController controller);
    }
}

