package tn.piapp.ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

import java.io.IOException;
import java.net.URL;
import java.util.function.Consumer;

public class IntegratedCovoiturageView extends StackPane {
    private static final String START_VIEW = "/tn/piapp/ui/covoiturage/views/covoiturages-view.fxml";
    private static final String STYLESHEET = "/tn/piapp/ui/covoiturage/styles/covoiturage.css";

    public IntegratedCovoiturageView() {
        try {
            show(START_VIEW, controller -> {
            });
        } catch (IOException exception) {
            showLoadError(exception);
        }
    }

    public static IntegratedCovoiturageView findOwner(Node node) {
        Node current = node;
        while (current != null) {
            if (current instanceof IntegratedCovoiturageView view) {
                return view;
            }
            current = current.getParent();
        }
        return null;
    }

    public void show(String fxmlPath, Consumer<Object> controllerConfigurer) throws IOException {
        FXMLLoader loader = new FXMLLoader(IntegratedCovoiturageView.class.getResource(fxmlPath));
        Parent root = loader.load();
        controllerConfigurer.accept(loader.getController());

        URL stylesheet = IntegratedCovoiturageView.class.getResource(STYLESHEET);
        if (stylesheet != null) {
            String stylesheetUrl = stylesheet.toExternalForm();
            if (!getStylesheets().contains(stylesheetUrl)) {
                getStylesheets().add(stylesheetUrl);
            }
        }

        getChildren().setAll(root);
    }

    private void showLoadError(Exception exception) {
        Label label = new Label("Impossible de charger le module covoiturage : " + exception.getMessage());
        label.setStyle("-fx-padding: 24; -fx-text-fill: #e74c3c; -fx-font-weight: bold;");
        getChildren().setAll(label);
    }
}
