package tn.piapp.ui.covoiturage;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.print.PrinterJob;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import com.rentall.covoiturage.models.Covoiturage;
import com.rentall.covoiturage.services.CovoiturageService;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StatistiquesCovoiturageController {
    private static final DecimalFormat PRICE_FORMAT = new DecimalFormat("0.00");
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final CovoiturageService covoiturageService = new CovoiturageService();

    @FXML
    private BorderPane rootPane;

    @FXML
    private Label totalCovoituragesValue;

    @FXML
    private Label totalPlacesValue;

    @FXML
    private Label prixMoyenValue;

    @FXML
    private Label conducteursValue;

    @FXML
    private Label prochainDepartValue;

    @FXML
    private Label statusLabel;

    @FXML
    private PieChart departPieChart;

    @FXML
    private BarChart<String, Number> placesBarChart;

    public void chargerStatistiques() {
        try {
            List<Covoiturage> covoiturages = covoiturageService.getAllCovoiturages();
            CovoiturageService.CovoiturageStatistiques statistiques = covoiturageService.calculerStatistiques(covoiturages);

            totalCovoituragesValue.setText(String.valueOf(statistiques.getTotalCovoiturages()));
            totalPlacesValue.setText(String.valueOf(statistiques.getTotalPlaces()));
            prixMoyenValue.setText(PRICE_FORMAT.format(statistiques.getPrixMoyen()) + " DT");
            conducteursValue.setText(String.valueOf(statistiques.getTotalConducteurs()));
            prochainDepartValue.setText(formatDateTime(statistiques.getProchainDepart()));

            chargerPieChart(covoiturages);
            chargerBarChart(covoiturages);
            afficherSucces("Statistiques chargees avec succes.");
        } catch (SQLException exception) {
            afficherErreur("Impossible de charger les statistiques : " + exception.getMessage());
        }
    }

    @FXML
    private void actualiserStatistiques() {
        chargerStatistiques();
    }

    @FXML
    private void imprimerStatistiques() {
        PrinterJob printerJob = PrinterJob.createPrinterJob();
        if (printerJob == null) {
            afficherErreur("Aucune imprimante n'est disponible.");
            return;
        }

        boolean proceed = printerJob.showPrintDialog(rootPane.getScene().getWindow());
        if (!proceed) {
            afficherErreur("Impression annulee.");
            return;
        }

        boolean success = printerJob.printPage(rootPane);
        if (success) {
            printerJob.endJob();
            afficherSucces("Impression lancee avec succes.");
        } else {
            afficherErreur("L'impression a echoue.");
        }
    }

    @FXML
    private void fermerFenetre() {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.close();
    }

    private void chargerPieChart(List<Covoiturage> covoiturages) {
        Map<String, Integer> repartitionParVille = new TreeMap<>();
        for (Covoiturage covoiturage : covoiturages) {
            repartitionParVille.merge(covoiturage.getVilleDepart(), 1, Integer::sum);
        }

        departPieChart.setData(FXCollections.observableArrayList(
                repartitionParVille.entrySet().stream()
                        .map(entry -> new PieChart.Data(entry.getKey(), entry.getValue()))
                        .toList()
        ));
        departPieChart.setLabelsVisible(true);
        departPieChart.setLegendVisible(true);
    }

    private void chargerBarChart(List<Covoiturage> covoiturages) {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Places disponibles");

        for (Covoiturage covoiturage : covoiturages) {
            String route = covoiturage.getVilleDepart() + " -> " + covoiturage.getVilleArrivee();
            series.getData().add(new XYChart.Data<>(route, covoiturage.getNbPlaces()));
        }

        placesBarChart.getData().clear();
        placesBarChart.getData().add(series);
        placesBarChart.setLegendVisible(false);
    }

    private String formatDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "Aucun depart disponible";
        }
        return dateTime.format(DATE_TIME_FORMAT);
    }

    private void afficherSucces(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-error");
        if (!statusLabel.getStyleClass().contains("status-success")) {
            statusLabel.getStyleClass().add("status-success");
        }
    }

    private void afficherErreur(String message) {
        statusLabel.setText(message);
        statusLabel.getStyleClass().remove("status-success");
        if (!statusLabel.getStyleClass().contains("status-error")) {
            statusLabel.getStyleClass().add("status-error");
        }
    }
}

