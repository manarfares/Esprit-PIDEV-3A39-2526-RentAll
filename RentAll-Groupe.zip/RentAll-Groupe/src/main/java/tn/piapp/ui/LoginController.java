package tn.piapp.ui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import tn.piapp.model.User;
import tn.piapp.dao.ServiceUser;
import tn.piapp.service.FaceVerificationService;
import tn.piapp.service.OAuthService;
import tn.piapp.util.FaceCaptureDialog;
import tn.piapp.util.SessionManager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class LoginController {

    @FXML private TextField     tfUsername;
    @FXML private PasswordField pfPassword;
    @FXML private Label         lblErreur;

    private ServiceUser service = new ServiceUser();
    private final OAuthService            oauth       = new OAuthService();
    private final FaceVerificationService faceService = new FaceVerificationService();

    @FXML
    public void handleLogin() {
        String name = tfUsername.getText().trim();
        String password = pfPassword.getText().trim();

        if (name.isEmpty() || password.isEmpty()) {
            lblErreur.setText("⚠️ Veuillez remplir tous les champs.");
            return;
        }

        User user = service.login(name, password);

        if (user == null) {
            lblErreur.setText("❌ Identifiant ou mot de passe incorrect.");
            return;
        }

        if (user.getStatus().equals("BANNED")) {
            lblErreur.setText("🚫 Votre compte est banni.");
            return;
        }

        if (user.getStatus().equals("INACTIVE")) {
            lblErreur.setText("⚠️ Votre compte est inactif.");
            return;
        }

        if (!service.verifierToken(user.getId(), user.getSessionToken())) {
            lblErreur.setText("❌ Erreur de session.");
            return;
        }

        SessionManager.getInstance().setCurrentUser(user);

        try {
            String fxml;
            FXMLLoader loader;
            Parent root;

            switch (user.getRole()) {
                case "ROLE_ADMIN":
                    fxml   = "/dashboard_admin.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root   = loader.load();
                    AdminController adminCtrl = loader.getController();
                    adminCtrl.setCurrentUser(user);
                    break;

                case "ROLE_HOST":
                case "ROLE_HOST_PENDING":
                    // Host vérifié ET non vérifié → même accueil
                    fxml   = "/home.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root   = loader.load();
                    HomeController hostCtrl = loader.getController();
                    hostCtrl.setCurrentUser(user);
                    break;

                default:
                    // Guest → accueil
                    fxml   = "/home.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root   = loader.load();
                    HomeController guestCtrl = loader.getController();
                    guestCtrl.setCurrentUser(user);
                    break;
            }

            Stage stage = (Stage) tfUsername.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setMaximized(true);
            stage.show();

        } catch (Exception e) {
            lblErreur.setText("❌ Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void handleGoRegister() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/register.fxml"));
            Stage stage = (Stage) tfUsername.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ====================================================================
    // ============== EXTENSIONS GESTIONUSERS (forgot / OAuth / face) =====
    // ====================================================================

    /** Aller a l'ecran "mot de passe oublie". */
    @FXML
    public void handleGoForgotPassword() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/forgot_password.fxml"));
            Stage stage = (Stage) tfUsername.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Connexion via Google OAuth. */
    @FXML
    public void handleGoogleLogin() {
        lblErreur.setStyle("-fx-text-fill: #2980b9; -fx-font-size: 11px;");
        lblErreur.setText("⏳ Ouverture de Google...");
        new Thread(() -> {
            try {
                OAuthService.OAuthUserInfo info = oauth.loginWithGoogle();
                User user = service.findOrCreateOAuthUser(info.email, info.name, info.picture, info.provider);
                Platform.runLater(() -> {
                    if (user == null) {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ Compte Google refuse.");
                        return;
                    }
                    finishOAuthLogin(user);
                });
            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                    lblErreur.setText("❌ OAuth Google : " + e.getMessage());
                });
            }
        }, "oauth-google").start();
    }

    /** Connexion via Facebook OAuth. */
    @FXML
    public void handleFacebookLogin() {
        lblErreur.setStyle("-fx-text-fill: #2980b9;");
        lblErreur.setText("⏳ Ouverture de Facebook...");
        new Thread(() -> {
            try {
                OAuthService.OAuthUserInfo info = oauth.loginWithFacebook();
                User user = service.findOrCreateOAuthUser(info.email, info.name, info.picture, info.provider);
                Platform.runLater(() -> {
                    if (user == null) {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ Compte Facebook refuse.");
                        return;
                    }
                    finishOAuthLogin(user);
                });
            } catch (Exception e) {
                e.printStackTrace();
                Platform.runLater(() -> {
                    lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                    lblErreur.setText("❌ OAuth Facebook : " + e.getMessage());
                });
            }
        }, "oauth-facebook").start();
    }

    /** Connexion par reconnaissance faciale. */
    @FXML
    public void handleFaceLogin() {
        var owner = lblErreur.getScene().getWindow();
        File probe = FaceCaptureDialog.show(owner, "Connexion faciale - RentAll");
        if (probe == null) return;

        lblErreur.setStyle("-fx-text-fill: #2980b9;");
        lblErreur.setText("⏳ Analyse du visage...");

        new Thread(() -> {
            try {
                List<User> candidates = service.findFaceLoginCandidates();
                if (candidates.isEmpty()) {
                    Platform.runLater(() -> {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ Aucun compte avec photo enregistree.");
                    });
                    return;
                }
                List<FaceVerificationService.FaceCandidate> payload = new ArrayList<>();
                for (User u : candidates) {
                    String selfieCol = service.getSelfieImagePath(u.getId());
                    String absPath = faceService.resolveAbsolutePath(selfieCol);
                    if (absPath != null && new File(absPath).isFile()) {
                        payload.add(new FaceVerificationService.FaceCandidate(u.getId(), absPath));
                    }
                }
                if (payload.isEmpty()) {
                    Platform.runLater(() -> {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ Photos de reference inaccessibles.");
                    });
                    return;
                }
                FaceVerificationService.IdentifyResult res = faceService.identifyUser(probe, payload);
                try { if (probe.getName().startsWith("face-capture-")) probe.delete(); } catch (Exception ignored) {}
                if (!res.success || !res.matched || res.userId == null) {
                    Platform.runLater(() -> {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ " + (res.error != null ? res.error : "Visage non reconnu."));
                    });
                    return;
                }
                User matched = service.findById(res.userId);
                if (matched == null) {
                    Platform.runLater(() -> {
                        lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                        lblErreur.setText("❌ Utilisateur introuvable.");
                    });
                    return;
                }
                String token = java.util.UUID.randomUUID().toString();
                service.saveTokenForUser(matched.getId(), token);
                matched.setSessionToken(token);
                Platform.runLater(() -> {
                    lblErreur.setStyle("-fx-text-fill: #27ae60;");
                    lblErreur.setText("✅ Bienvenue " + matched.getName());
                    finishOAuthLogin(matched);
                });
            } catch (Exception ex) {
                ex.printStackTrace();
                Platform.runLater(() -> {
                    lblErreur.setStyle("-fx-text-fill: #e74c3c;");
                    lblErreur.setText("❌ Erreur : " + ex.getMessage());
                });
            }
        }, "face-login").start();
    }

    /** Etape commune apres OAuth/Face login : redirection. */
    private void finishOAuthLogin(User user) {
        if ("BANNED".equalsIgnoreCase(user.getStatus())) {
            lblErreur.setStyle("-fx-text-fill: #e74c3c;");
            lblErreur.setText("🚫 Compte banni.");
            return;
        }
        SessionManager.getInstance().setCurrentUser(user);
        try {
            String fxml;
            FXMLLoader loader;
            Parent root;
            switch (user.getRole()) {
                case "ROLE_ADMIN":
                    fxml = "/dashboard_admin.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root = loader.load();
                    AdminController adminCtrl = loader.getController();
                    adminCtrl.setCurrentUser(user);
                    break;
                case "ROLE_HOST":
                case "ROLE_HOST_PENDING":
                    fxml = "/home.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root = loader.load();
                    HomeController hostCtrl = loader.getController();
                    hostCtrl.setCurrentUser(user);
                    break;
                default:
                    fxml = "/home.fxml";
                    loader = new FXMLLoader(getClass().getResource(fxml));
                    root = loader.load();
                    HomeController guestCtrl = loader.getController();
                    guestCtrl.setCurrentUser(user);
                    break;
            }
            Stage stage = (Stage) tfUsername.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setMaximized(true);
            stage.show();
        } catch (Exception e) {
            lblErreur.setStyle("-fx-text-fill: #e74c3c;");
            lblErreur.setText("❌ Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
