@echo off
echo ========================================
echo   Tests CRUD - RentAll (Console)
echo ========================================
echo.
echo Execution des tests CRUD en cours...
echo.

REM Sauvegarde temporaire de la configuration
set TEMP_MAIN_CLASS=com.rentall.Main

REM Modification temporaire du pom.xml pour pointer vers Main
powershell -Command "(Get-Content pom.xml) -replace '<mainClass>com.rentall.views.App</mainClass>', '<mainClass>com.rentall.Main</mainClass>' | Set-Content pom.xml"

REM Execution
"%USERPROFILE%\Downloads\apache-maven-3.9.15-bin (1)\apache-maven-3.9.15\bin\mvn.cmd" exec:java

REM Restauration du pom.xml
powershell -Command "(Get-Content pom.xml) -replace '<mainClass>com.rentall.Main</mainClass>', '<mainClass>com.rentall.views.App</mainClass>' | Set-Content pom.xml"

echo.
echo ========================================
pause
