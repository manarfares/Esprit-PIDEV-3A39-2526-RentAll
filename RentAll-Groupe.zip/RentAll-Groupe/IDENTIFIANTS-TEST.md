# 🔐 Identifiants de Connexion

## 📋 Utilisateurs de Test Courants

Essayez ces identifiants pour vous connecter à l'application :

### Option 1 : Admin
```
Username: admin
Password: admin
```
ou
```
Email: admin@rentall.com
Password: admin123
```

### Option 2 : Host (Hôte)
```
Username: host
Password: host123
```
ou
```
Email: host@rentall.com
Password: host123
```

### Option 3 : Guest (Invité)
```
Username: guest
Password: guest123
```
ou
```
Email: guest@rentall.com
Password: guest123
```

### Option 4 : Utilisateur Simple
```
Username: user
Password: user123
```

## 🔍 Vérifier les Utilisateurs dans la Base

Si aucun des identifiants ci-dessus ne fonctionne, vous devez vérifier directement dans la base de données MySQL :

### Via phpMyAdmin (XAMPP/WAMP)
1. Ouvrez phpMyAdmin : http://localhost/phpmyadmin
2. Sélectionnez la base `pidev_amine`
3. Cliquez sur la table `user`
4. Regardez les colonnes `name`, `email`, et `roles`

### Via MySQL Command Line
```sql
USE pidev_amine;
SELECT id, name, email, roles, status FROM user;
```

## 🆕 Créer un Nouvel Utilisateur

Si la table `user` est vide, vous pouvez créer un utilisateur directement en SQL :

```sql
USE pidev_amine;

-- Créer un admin (mot de passe: admin123)
INSERT INTO user (name, email, password, roles, status, created_at) 
VALUES (
    'admin', 
    'admin@rentall.com', 
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '["ROLE_ADMIN"]',
    'ACTIVE',
    NOW()
);

-- Créer un host (mot de passe: host123)
INSERT INTO user (name, email, password, roles, status, created_at) 
VALUES (
    'host', 
    'host@rentall.com', 
    '$2a$10$8K1p/a0dL1LkW0/QwJ3OeOUHTYh/Pq2auddkyO0.Fmb4T7aoUKkLC',
    '["ROLE_HOST"]',
    'ACTIVE',
    NOW()
);

-- Créer un guest (mot de passe: guest123)
INSERT INTO user (name, email, password, roles, status, created_at) 
VALUES (
    'guest', 
    'guest@rentall.com', 
    '$2a$10$DpwmetQQMjfwoVYVz7Bc..XYenNnYkqUJnRy6zDfaUiVIpd6ssm5u',
    '["ROLE_GUEST"]',
    'ACTIVE',
    NOW()
);
```

## ⚠️ Note sur les Mots de Passe

Les mots de passe sont hashés avec **BCrypt**. Vous ne pouvez pas voir le mot de passe en clair dans la base de données.

Si vous avez oublié le mot de passe d'un utilisateur existant, vous devez :
1. Soit réinitialiser le mot de passe en SQL
2. Soit créer un nouvel utilisateur

## 🔄 Réinitialiser un Mot de Passe

Pour réinitialiser le mot de passe d'un utilisateur existant (exemple: mettre "newpass123") :

```sql
USE pidev_amine;

-- Hash BCrypt pour "newpass123"
UPDATE user 
SET password = '$2a$10$rZ6zZqjnLY5L5vK5vK5vKOqZ5L5vK5vK5vK5vK5vK5vK5vK5vK5vK'
WHERE name = 'admin';
```

**Note:** Le hash ci-dessus est un exemple. Pour générer un vrai hash BCrypt, utilisez un outil en ligne ou le code Java.

## 📞 Besoin d'Aide ?

Si vous ne parvenez toujours pas à vous connecter :
1. Vérifiez que MySQL est démarré (XAMPP/WAMP)
2. Vérifiez que la base `pidev_amine` existe
3. Vérifiez que la table `user` contient des données
4. Vérifiez les logs dans la console pour voir les erreurs

---
**Astuce :** Après la connexion, vous verrez l'interface principale avec les boutons **Réservations** et **Avis** dans la navbar !
