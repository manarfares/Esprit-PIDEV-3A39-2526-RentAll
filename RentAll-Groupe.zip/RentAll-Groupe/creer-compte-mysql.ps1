# Script PowerShell pour créer le compte de test dans MySQL
# Email: test@example.com
# Password: 123456

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Creation du compte de test MySQL" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Chemins possibles pour MySQL
$mysqlPaths = @(
    "C:\xampp\mysql\bin\mysql.exe",
    "C:\wamp64\bin\mysql\mysql8.0.31\bin\mysql.exe",
    "C:\wamp64\bin\mysql\mysql8.0.30\bin\mysql.exe",
    "C:\wamp64\bin\mysql\mysql8.0.29\bin\mysql.exe",
    "C:\wamp\bin\mysql\mysql8.0.31\bin\mysql.exe",
    "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe",
    "C:\Program Files\MySQL\MySQL Server 5.7\bin\mysql.exe"
)

$mysqlExe = $null
foreach ($path in $mysqlPaths) {
    if (Test-Path $path) {
        $mysqlExe = $path
        Write-Host "✓ MySQL trouvé: $path" -ForegroundColor Green
        break
    }
}

if ($null -eq $mysqlExe) {
    Write-Host "✗ MySQL non trouvé automatiquement." -ForegroundColor Red
    Write-Host ""
    Write-Host "Solutions alternatives:" -ForegroundColor Yellow
    Write-Host "1. Ouvrez phpMyAdmin: http://localhost/phpmyadmin" -ForegroundColor Yellow
    Write-Host "2. Sélectionnez la base 'pidev_amine'" -ForegroundColor Yellow
    Write-Host "3. Cliquez sur 'SQL' et exécutez le contenu du fichier:" -ForegroundColor Yellow
    Write-Host "   create-test-account.sql" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Ou utilisez le fichier create-test-account.sql dans phpMyAdmin" -ForegroundColor Yellow
    pause
    exit
}

Write-Host ""
Write-Host "Création du compte en cours..." -ForegroundColor Yellow

$sql = @"
USE pidev_amine;
DELETE FROM user WHERE email = 'test@example.com';
INSERT INTO user (name, email, password, roles, status, created_at, updated_at) 
VALUES (
    'Test Admin',
    'test@example.com',
    '\$2a\$10\$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '[\"ROLE_ADMIN\"]',
    'ACTIVE',
    NOW(),
    NOW()
);
SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';
"@

try {
    $result = & $mysqlExe -u root -e $sql 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✓ Compte créé avec succès!" -ForegroundColor Green
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host "  IDENTIFIANTS DE CONNEXION" -ForegroundColor Cyan
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  Email:        test@example.com" -ForegroundColor White
        Write-Host "  Mot de passe: 123456" -ForegroundColor White
        Write-Host "  Rôle:         ADMIN" -ForegroundColor White
        Write-Host ""
        Write-Host "Résultat de la requête:" -ForegroundColor Yellow
        Write-Host $result
    } else {
        Write-Host "✗ Erreur lors de la création du compte" -ForegroundColor Red
        Write-Host $result
    }
} catch {
    Write-Host "✗ Erreur: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
pause
