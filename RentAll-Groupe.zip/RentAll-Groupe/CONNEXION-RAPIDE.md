# 🚀 CONNEXION RAPIDE - 3 ÉTAPES

## ⚡ Étape 1 : Ouvrez phpMyAdmin

Dans votre navigateur, allez sur :
```
http://localhost/phpmyadmin
```

## ⚡ Étape 2 : Exécutez ce SQL

1. Cliquez sur la base **`pidev_amine`** (menu de gauche)
2. Cliquez sur l'onglet **`SQL`** (en haut)
3. **Copiez-collez** ce code :

```sql
DELETE FROM user WHERE email = 'test@example.com';

INSERT INTO user (name, email, password, roles, status, created_at, updated_at) 
VALUES (
    'Test Admin',
    'test@example.com',
    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
    '["ROLE_ADMIN"]',
    'ACTIVE',
    NOW(),
    NOW()
);
```

4. Cliquez sur **`Exécuter`** (bouton en bas à droite)

## ⚡ Étape 3 : Connectez-vous

Retournez dans l'application RentAll et connectez-vous avec :

```
📧 Email:        test@example.com
🔑 Mot de passe: 123456
```

---

## ✅ C'est tout !

Une fois connecté, vous verrez :
- L'interface principale du groupe
- Les boutons **📅 Réservations** et **⭐ Avis** dans la navbar
- Cliquez dessus pour accéder à vos modules !

---

## 🔍 Vérification (optionnel)

Pour vérifier que le compte a été créé, exécutez dans phpMyAdmin :

```sql
SELECT id, name, email, roles, status FROM user WHERE email = 'test@example.com';
```

Vous devriez voir une ligne avec vos informations.

---

## ❓ Problèmes ?

### Le SQL ne s'exécute pas
- Vérifiez que vous êtes bien dans la base `pidev_amine`
- Vérifiez qu'il n'y a pas d'erreur de syntaxe (copiez exactement le code)

### Le login échoue toujours
- Vérifiez que le compte existe (requête SELECT ci-dessus)
- Vérifiez que le status est 'ACTIVE'
- Essayez de fermer et rouvrir l'application

### MySQL/phpMyAdmin ne s'ouvre pas
- Démarrez XAMPP ou WAMP
- Vérifiez que MySQL est démarré (voyant vert)
- Essayez http://localhost:8080/phpmyadmin si le port 80 est occupé

---

**Bon test !** 🎉
