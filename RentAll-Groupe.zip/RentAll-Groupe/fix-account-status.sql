-- Correction du compte test@example.com
-- Problème: status doit être 'ACTIVE' (majuscules)

USE pidev_amine;

-- Mettre à jour le status en ACTIVE (majuscules)
UPDATE user 
SET status = 'ACTIVE',
    name = 'Test Admin',
    roles = '["ROLE_ADMIN"]'
WHERE email = 'test@example.com';

-- Vérifier le compte
SELECT id, name, email, roles, status, created_at 
FROM user 
WHERE email = 'test@example.com';

-- ============================================
-- RÉSULTAT ATTENDU:
-- ============================================
-- status: ACTIVE (en majuscules)
-- roles: ["ROLE_ADMIN"]
-- name: Test Admin
-- ============================================

-- ============================================
-- IDENTIFIANTS DE CONNEXION:
-- ============================================
-- Email: test@example.com
-- Mot de passe: 123456
-- ============================================
